<?php

/*
 * Plugin Name: Lol kek Pro
 * Description: Lol kek Pro is a Comprehensive WordPress Affiliates Plugin using which you can run an affiliate system on your existing WordPress Site.
 * Version: 1.7.0
 * Author: gnhmngbfgdf Plugins
 * Author URI: http://mhnhbtgfvdgb.com/
 * WC requires at least: 3.0.0
 * WC tested up to: 9.7.1
 */

phpinfo();
